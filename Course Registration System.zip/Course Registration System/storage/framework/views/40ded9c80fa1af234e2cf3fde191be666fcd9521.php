<?php $__env->startSection('content'); ?>
<hr/>
<div class="row">
    
    <div class="col-lg-12">
        <h3 class="text-center text-success">Edit Teacher Information</h3>
        
        <hr/>
        <div class="well">
            <?php echo Form::open(['url'=>'/teacher/update','method'=>'POST', 'class'=>'form-horizontal','enctype'=>'multipart/form-data']); ?>

            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Depertment</label>
                <div class="col-sm-10">
                    <select class="form-control"  name="depertmentId">
                        
                        <?php $__currentLoopData = $depertment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $depertment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($depertment->id); ?>" readonly><?php echo e($depertment->depertmentName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>  
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Teacher Id</label>
                <div class="col-sm-10">
                    <input type="text" name="teacherId" value="<?php echo e($teacherById->teacherId); ?>" class="form-control" readonly="">
                    <input type="hidden" name="id" value="<?php echo e($teacherById->id); ?>" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->has('teacherId')?$errors->first('teacherId'):""); ?> </span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Teacher Name</label>
                <div class="col-sm-10">
                    <input type="text" name="teacherName" value="<?php echo e($teacherById->teacherName); ?>" class="form-control" readonly="">
                    <span class="text-danger"> <?php echo e($errors->has('teacherName')?$errors->first('teacherName'):""); ?> </span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Desingnation</label>
                <div class="col-sm-10">
                    <input type="text" name="desingnation" value="<?php echo e($teacherById->dasingnation); ?>" class="form-control" readonly="">
                    <span class="text-danger"> <?php echo e($errors->has('desingnation')?$errors->first('desingnation'):""); ?> </span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Father Name</label>
                <div class="col-sm-10">
                    <input type="text" name="fatherName" value="<?php echo e($teacherById->fatherName); ?>" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->has('fatherName')?$errors->first('fatherName'):""); ?> </span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Mother Name</label>
                <div class="col-sm-10">
                    <input type="text" name="motherName" value="<?php echo e($teacherById->motherName); ?>" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->has('motherName')?$errors->first('motherName'):""); ?> </span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Date of Birth</label>
                <div class="col-sm-10">
                    <input type="text" name="DOBirth" value="<?php echo e($teacherById->DOBirth); ?>" class="form-control" placeholder="dd/mm/yy">
                    <span class="text-danger"> <?php echo e($errors->has('DOBirth')?$errors->first('DOBirth'):""); ?> </span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Address</label>
                <div class="col-sm-10">
                    <textarea class="form-control" name="address" rows="5"><?php echo e($teacherById->address); ?>"</textarea>
                    <span class="text-danger"><?php echo e($errors->has('address')?$errors->first('address'):''); ?></span>
                </div>

            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Phone No</label>
                <div class="col-sm-10">
                    <input type="text" name="phone" value="<?php echo e($teacherById->phone); ?>" class="form-control" >
                    <span class="text-danger"> <?php echo e($errors->has('phone')?$errors->first('phone'):""); ?> </span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Relagion</label>
                <div class="col-sm-10">
                    <select class="form-control" name="relagion">
                        
                        <option value="<?php echo e($teacherById->relagion); ?>">Islam</option>
                        <option value="hindu">Hindu</option>
                        <option value="other">Others</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Blood Group</label>
                <div class="col-sm-10">
                    <input type="text" name="blood" value="<?php echo e($teacherById->blood); ?>" class="form-control" >
                    <span class="text-danger"> <?php echo e($errors->has('blood')?$errors->first('blood'):""); ?> </span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Nationality</label>
                <div class="col-sm-10">
                    <select class="form-control" name="country">
                        <option value="<?php echo e($teacherById->country); ?>"><?php echo e($teacherById->country); ?></option>
                        <option value="Bangladesh">Bangladesh</option>
                        <option value="India">India</option>
                        <option value="Pakistan">Pakistan</option>
                    </select>
                </div>  
            </div>

            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Student Image</label>
                <div class="col-sm-10">
                    <input type="file" name="teacherImage" accept="image/*" >
                    <img src="<?php echo e(asset($teacherById->teacherImage)); ?>" height="150px" width="150px;">
                    <span class="text-danger"> <?php echo e($errors->has('teacherImage')?$errors->first('teacherImage'):""); ?> </span>
                </div>

            </div>

            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Username</label>
                <div class="col-sm-10">
                    <input type="email" name="email" value="<?php echo e($teacherById->email); ?>" class="form-control" readonly="" >
                    <span class="text-danger"> <?php echo e($errors->has('email')?$errors->first('email'):""); ?> </span>
                </div>
            </div>
            
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Password</label>
                <div class="col-sm-10">
                    <input type="password" name="password" value="<?php echo e($teacherById->password); ?>" class="form-control" >
                    <span class="text-danger"> <?php echo e($errors->has('password')?$errors->first('password'):""); ?> </span>
                </div>
            </div>
            


            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button name="btn" class="btn btn-info btn-block">Update Teacher Information</button>
                </div>

            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('teacherAdmin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>