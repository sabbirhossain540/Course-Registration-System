<!--
author: W3layouts
author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Daffodil International University | Home </title>
        <!-- custom-theme -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Mastering Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
              Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
            function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!-- //custom-theme -->
        <link href="<?php echo e(asset('public/frontEnd/css/bootstrap.css')); ?>" rel="stylesheet" type="text/css" media="all" />
        <link href="<?php echo e(asset('public/frontEnd/')); ?>/css/JiSlider.css" rel="stylesheet"> 
        <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/')); ?>/css/flexslider.css" type="text/css" media="screen" property="" />

        <link href="<?php echo e(asset('public/frontEnd/')); ?>/css/style.css" rel="stylesheet" type="text/css" media="all" />

        <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/')); ?>/css/flexslider.css" type="text/css" media="screen" property="" />
        <!-- font-awesome-icons -->
        <link href="<?php echo e(asset('public/frontEnd/')); ?>/css/font-awesome.css" rel="stylesheet"> 
        <!-- //font-awesome-icons -->
        <link href="//fonts.googleapis.com/css?family=Raleway:400,400i,500,500i,600,600i,700,700i,800" rel="stylesheet">
        <link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
    </head>

    <body>
        <!-- banner -->
        <?php echo $__env->make('frontEnd.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- banner -->
        <?php echo $__env->yieldContent('mainContent'); ?>
        <!-- //testimonials -->	

        <!-- footer -->
        <?php echo $__env->make('frontEnd.include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- //footer -->
        <!-- start-smoth-scrolling -->
        <!-- js -->
        <?php echo $__env->yieldContent('java'); ?>
        <script type="text/javascript" src="<?php echo e(asset('public/frontEnd/')); ?>/js/jquery-2.1.4.min.js"></script>
        <!-- //js -->
        <script src="<?php echo e(asset('public/frontEnd/')); ?>/js/JiSlider.js"></script>
        <script>
$(window).load(function () {
    $('#JiSlider').JiSlider({color: '#fff', start: 3, reverse: true}).addClass('ff')
})
        </script><script type="text/javascript">

            var _gaq = _gaq || [];
            _gaq.push(['_setAccount', 'UA-36251023-1']);
            _gaq.push(['_setDomainName', 'jqueryscript.net']);
            _gaq.push(['_trackPageview']);

            (function () {
                var ga = document.createElement('script');
                ga.type = 'text/javascript';
                ga.async = true;
                ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
                var s = document.getElementsByTagName('script')[0];
                s.parentNode.insertBefore(ga, s);
            })();

        </script>
        <!-- stats -->
        <script src="<?php echo e(asset('public/frontEnd/')); ?>/js/jquery.waypoints.min.js"></script>
        <script src="<?php echo e(asset('public/frontEnd/')); ?>/js/jquery.countup.js"></script>
        <script>
            $('.counter').countUp();
        </script>
        <!-- //stats -->
        <!-- //footer -->
        <!-- flexSlider -->
        <script defer src="<?php echo e(asset('public/frontEnd/')); ?>/js/jquery.flexslider.js"></script>
        <script type="text/javascript">
            $(window).load(function () {
                $('.flexslider').flexslider({
                    animation: "slide",
                    start: function (slider) {
                        $('body').removeClass('loading');
                    }
                });
            });
        </script>
        <!-- //flexSlider -->


        <script type="text/javascript" src="<?php echo e(asset('public/frontEnd/')); ?>/js/move-top.js"></script>
        <script type="text/javascript" src="<?php echo e(asset('public/frontEnd/')); ?>/js/easing.js"></script>
        <script type="text/javascript">
            jQuery(document).ready(function ($) {
                $(".scroll").click(function (event) {
                    event.preventDefault();
                    $('html,body').animate({scrollTop: $(this.hash).offset().top}, 1000);
                });
            });
        </script>
        <!-- start-smoth-scrolling -->
        <!-- for bootstrap working -->
        <script src="<?php echo e(asset('public/frontEnd/')); ?>/js/bootstrap.js"></script>
        <!-- //for bootstrap working -->
        <!-- here stars scrolling icon -->
        <script type="text/javascript">
            $(document).ready(function () {
                /*
                 var defaults = {
                 containerID: 'toTop', // fading element id
                 containerHoverID: 'toTopHover', // fading element hover id
                 scrollSpeed: 1200,
                 easingType: 'linear' 
                 };
                 */

                $().UItoTop({easingType: 'easeOutQuart'});

            });
        </script>
        <!-- //here ends scrolling icon -->
    </body>
</html>