<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-2"></div>
    <div class="col-lg-10">
        <h3 class="text-center text-denger"><?php echo e(Session::get('massege')); ?></h3>
        <hr/>

        <div class="well">

            <h3 class="text-center text-success">Samister Wise Course List</h3>
            <hr/>

            <table class="table table-hover table-bordered">
                <thead>
                    <tr>


                        <th>Course Name</th>
                        <th>Samister</th>
                        <th>Status</th>

                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                        <td><?php echo e($course->samisterName); ?></td>
                        <td><?php echo e($course->courseName); ?></td>
                        <td><?php echo e($course->status); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('studentAdmin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>