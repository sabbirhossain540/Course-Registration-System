<?php $__env->startSection('content'); ?>
<hr/>
<div class="row">
    <div class="col-lg-1"></div>
    <div class="col-lg-10">
        <h3 class="text-center text-success"><?php echo e(Session::get('massege')); ?></h3>
        <hr/>
        <div class="well">
            <?php echo Form::open(['url'=>'/course/update','method'=>'POST', 'class'=>'form-horizontal', 'name'=>'editCourseForm']); ?>

            <div class="form-group">
                <label for="inputEmail3" value="<?php echo e($courseById->courseCode); ?>" class="col-sm-2 control-label">Course Code</label>
                <div class="col-sm-10">
                    <input type="text" name="courseCode" value="<?php echo e($courseById->courseCode); ?>" class="form-control">
                    <input type="hidden" name="id" value="<?php echo e($courseById->id); ?>" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->has('courseCode')?$errors->first('courseCode'):""); ?> </span>
                </div>

            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Course Name</label>
                <div class="col-sm-10">
                    <input type="text" name="courseName" value="<?php echo e($courseById->courseName); ?>" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->has('courseName')?$errors->first('courseName'):""); ?> </span>
                </div>

            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Depertment Name</label>
                <div class="col-sm-10">
                    <select class="form-control" name="depertmentName" id="depertmentName" >
                        
                        
                        <?php $__currentLoopData = $depertment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $depertment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($depertment->id); ?>"><?php echo e($depertment->depertmentName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

            </div>
            
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Course Instructor</label>
                <div class="col-sm-10">
                    <select class="form-control" name="courseInstructor">
                       
                         <?php $__currentLoopData = $teacher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($teacher->id); ?>"><?php echo e($teacher->teacherName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Section</label>
                <div class="col-sm-10">
                    <input type="text" name="section" value="<?php echo e($courseById->section); ?>" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->has('section')?$errors->first('section'):""); ?> </span>
                </div>

            </div>
            
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Total Seat</label>
                <div class="col-sm-10">
                    <input type="number" name="seatNo" value="<?php echo e($courseById->seatNo); ?>" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->has('seatNo')?$errors->first('seatNo'):""); ?> </span>
                </div>

            </div>
            
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Publication Status</label>
                <div class="col-sm-10">
                    <select class="form-control" name="publicationStatus">
                        <option>Select Publication Status</option>
                        <option value="1">Published</option>
                        <option value="0">Unpublished</option>
                    </select>
                </div>

            </div>

            

            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button name="btn" class="btn btn-success btn-block">Update Course Information</button>
                </div>

            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<script>
    document.forms['editCourseForm'].elements['publicationStatus'].value=<?php echo e($courseById->publicationStatus); ?>

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>