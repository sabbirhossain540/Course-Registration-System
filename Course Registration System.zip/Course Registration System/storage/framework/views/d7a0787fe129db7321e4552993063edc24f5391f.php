<?php $__env->startSection('content'); ?>
<div class="row">
  
    <div class="col-lg-12">
        <h3 class="text-center text-success">Student List</h3>
        <hr/>
        <div class="well">
            
            <table class="table table-hover table-bordered">
                <thead>
                    <tr>
                        <th>Student Id</th>
                        <th>Student Name</th>
                        <th>Depertment</th>
                        <th>Phone No</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td scope="row"><?php echo e($student->studentId); ?></td>
                        <td><?php echo e($student->studentName); ?></td>
                        <td><?php echo e($student->depertmentName); ?></td>
                        <td><?php echo e($student->phone); ?></td>
                        <td>
                            <a href="<?php echo e(url('/studentInformation/view/'.$student->id)); ?>" class="btn btn-info">
                                <span class="glyphicon glyphicon-info-sign"></span>
                            </a>
                            <a href="<?php echo e(url('/studentInformation/course/'.$student->id)); ?>" class="btn btn-success">
                                <span class="glyphicon glyphicon-edit"></span>
                            </a>
                            
                            
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('teacherAdmin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>