<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-1"></div>
    <div class="col-lg-10">
        <h3 class="text-center text-success"><?php echo e(Session::get('massege')); ?></h3>
        <hr/>
        <div class="well">
            <h3 class="text-center">Shedule Management</h3>
            <hr/>
            <table class="table table-hover table-bordered">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Section</th>
                        <th>Total Seat</th>
                        <th>Room No</th>
                        <th>Time Slot</th>
                        <th>Publication Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $shedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td scope="row"><?php echo e($shedule->id); ?></td>
                        <td><?php echo e($shedule->sectionName); ?></td>
                        <td><?php echo e($shedule->seatNo); ?></td>
                        <td><?php echo e($shedule->roomNo); ?></td>
                        <td><?php echo e($shedule->timeSlot); ?></td>
                        <td><?php echo e($shedule->publicationStatus == 1 ? 'Published':'Unpublished'); ?></td>
                        <td>
                            <a href="<?php echo e(url('/shedule/edit/'.$shedule->id)); ?>" class="btn btn-success">
                                <span class="glyphicon glyphicon-edit"></span>
                            </a>
                            <a href="<?php echo e(url('/shedule/delete/'.$shedule->id)); ?>" class="btn btn-danger" onclick="return confirm('Are you sure to delete This');">
                                <span class="glyphicon glyphicon-trash"></span>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>