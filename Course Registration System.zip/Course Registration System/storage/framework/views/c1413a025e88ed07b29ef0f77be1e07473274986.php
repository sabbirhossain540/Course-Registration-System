<?php $__env->startSection('content'); ?>
<div class="row">
  
    <div class="col-lg-12">
        <h3 class="text-center text-success">Registered Course List</h3>
        <hr/>
       
        <div class="well">
            
            <table class="table table-hover table-bordered">
                <thead>
                    <tr>
                        <th>Samister</th>
                        <th>Course Name</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $courseInformation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseInformation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td scope="row"><?php echo e($courseInformation->samisterName); ?></td>
                        <td><?php echo e($courseInformation->courseName); ?></td>
                        <td><?php echo e($courseInformation->status == 'Conform' ? 'Complete':''); ?></td>
                        
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('teacherAdmin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>