<div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="<?php echo e(url('/teacherDashbord')); ?>"><i class="fa fa-dashboard fa-fw nav_icon"></i>Dashboard</a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('/teacher/edit')); ?>"><i class="fa fa-laptop nav_icon"></i>Edit Profile<span class="fa arrow"></span></a>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="<?php echo e(url('/teacher/studentView')); ?>"><i class="fa fa-indent nav_icon"></i>View Student <span class="fa arrow"></span></a>
                            
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="<?php echo e(url('/viewPendingCourse')); ?>"><i class="fa fa-envelope nav_icon"></i>Course Conformation<span class="fa arrow"></span></a>
                            
                            <!-- /.nav-second-level -->
                        </li>
                       
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>