<?php $__env->startSection('content'); ?>
<div class="row">
    
    <div class="col-lg-12">
        
        <div class="well">
            <h3 class="text-center text-success">Student Profile </h3>
        <hr/>
            <div class="col-lg-3">
                <hr>
                <table class="table table-bordered table-hover">
                    <tr>
                        <th>Student Image</th>
                    </tr>
                    <tr>
                        <td><img src="<?php echo e(asset($student->studentImage)); ?>" alt="<?php echo e($student->studentName); ?>"  width="280px" height="300px"/></td>
                    </tr>
                </table>
            </div>
            <div class="col-lg-9">
                <hr>
                <table class="table table-bordered table-hover">
                    <tr>
                        <th>Student Id</th>
                        <th><?php echo e($student->studentId); ?></th>
                    </tr>
                    <tr>
                        <th>Student Name</th>
                        <th><?php echo e($student->studentName); ?></th>
                    </tr>
                    <tr>
                        <th>Depertment</th>
                        <th><?php echo e($student->depertmentName); ?></th>
                    </tr>
                    <tr>
                        <th>Father Name</th>
                        <th><?php echo e($student->fatherName); ?></th>
                    </tr>
                    <tr>
                        <th>Mother Name</th>
                        <th><?php echo e($student->motherName); ?></th>
                    </tr>
                    <tr>
                        <th>Dath of Birth</th>
                        <th><?php echo e($student->DOBirth); ?></th>
                    </tr>
                    <tr>
                        <th>Address</th>
                        <th><?php echo e($student->address); ?></th>
                    </tr>
                    <tr>
                        <th>Phone No</th>
                        <th><?php echo e($student->phone); ?></th>
                    </tr>
                    <tr>
                        <th>Relagion</th>
                        <th><?php echo e($student->relagion); ?></th>
                    </tr>
                    <tr>
                        <th>Blood</th>
                        <th><?php echo e($student->blood); ?></th>
                    </tr>
                    <tr>
                        <th>Country</th>
                        <th><?php echo e($student->country); ?></th>
                    </tr>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('teacherAdmin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>