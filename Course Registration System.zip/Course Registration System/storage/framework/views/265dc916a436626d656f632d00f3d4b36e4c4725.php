<?php $__env->startSection('content'); ?>

<div class="row">
    
    <div class="col-lg-12">
        <h3 class="text-center text-denger"><?php echo e(Session::get('massege')); ?></h3>
        <hr/>
        
        <div class="well">
            
            <h3 class="text-center text-success">Register Course List</h3>
            <hr/>
            <div class="col-lg-12" style="margin-bottom: 10px;">
                <form method="post" action="<?php echo e(url('/view/registerCourse')); ?>">
                <div class="form-group">
                    <label for="inputEmail3" class="col-sm-2 control-label"><input type="text" name="studentId" class="form-control" placeholder="Student Id"></label>
                    <label for="inputEmail3" class="col-sm-2 control-label"><input type="text" name="samisterName" class="form-control"></label>
                    <div class="col-sm-1">
                        <button name="btn" class="btn btn-success btn-block">Search</button>
                    </div>

                </div>
                
            </form>
        </div>
            
            <table class="table table-hover table-bordered">
                <thead>
                    <tr>
                        <th>Student Id</th>
                        <th>Student Name</th>
                        <th>Samister</th>
                        <th>Course Name</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pendingCourse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pendingCourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td scope="row"><?php echo e($pendingCourse->studentId); ?></td>
                        <td><?php echo e($pendingCourse->studentName); ?></td>
                        <td><?php echo e($pendingCourse->samisterName); ?></td>
                        <td><?php echo e($pendingCourse->courseName); ?></td>
                        <td><?php echo e($pendingCourse->status); ?></td>
                        <td>
                            <a href="<?php echo e(url('/pendingCourse/edit/'.$pendingCourse->id)); ?>" class="btn btn-success">
                                <span class="glyphicon glyphicon-edit"></span>
                            </a>
                            <a href="<?php echo e(url('/pandingCourse/delete/'.$pendingCourse->id)); ?>" class="btn btn-danger" onclick="return confirm('Are you sure to delete This');">
                                <span class="glyphicon glyphicon-trash"></span>
                            </a>
                        </td>
                        
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    
                    
                   
                </tbody>
            </table>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('teacherAdmin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>