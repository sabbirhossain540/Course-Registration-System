<?php $__env->startSection('content'); ?>
<hr/>
<div class="row">
    <div class="col-lg-2"></div>
    <div class="col-lg-8">
        <h3 class="text-center text-success"><?php echo e(Session::get('massege')); ?></h3>
        <hr/>
        <h3 class="text-center text-success">Course Registration Form</h3>
        <div class="well">

            <?php echo Form::open(['url'=>'/registerCourse/save','method'=>'POST', 'class'=>'form-horizontal']); ?>

            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Student Id</label>
                <div class="col-sm-10">
                    <input type="text" name="studentId" value="<?php echo e($studentInfo->studentId); ?>" class="form-control" readonly="">
                    <span class="text-danger"> <?php echo e($errors->has('studentId')?$errors->first('studentId'):""); ?> </span>
                </div>

            </div>
            <div class="form-group">
                
                <label for="inputEmail3" class="col-sm-2 control-label">Student Name</label>
                <div class="col-sm-10">
                    <input type="text" name="studentName" value="<?php echo e($studentInfo->studentName); ?>" class="form-control" readonly="">
                    <span class="text-danger"> <?php echo e($errors->has('studentName')?$errors->first('studentName'):""); ?> </span>
                </div>
          
            </div>
            <div class="form-group" hidden="" >
                <label for="inputEmail3" class="col-sm-2 control-label">Depertment</label>
                <div class="col-sm-10">
                    
                    <select class="form-control" name="depermentName">
                        <?php $__currentLoopData = $depertmentInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $depertmentInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($depertmentInfo->id); ?>"><?php echo e($depertmentInfo->depertmentName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
    
            </div>
            <div class="form-group" >
                <label for="inputEmail3" class="col-sm-2 control-label">Samister</label>
                <div class="col-sm-10">
                    
                    <select class="form-control" name="samisterName">
                        <?php $__currentLoopData = $samisterInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $samisterInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($samisterInfo->id); ?>"><?php echo e($samisterInfo->samisterName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
    
            </div>

            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Select Course</label>
                <div class="col-sm-10">
                    <select class="form-control" name="courseName">
                        <?php $__currentLoopData = $courseInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($courseInfo->id); ?>"><?php echo e($courseInfo->courseName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="form-group" hidden="">
                <label for="inputEmail3" class="col-sm-2 control-label">Status</label>
                <div class="col-sm-10">
                    <select class="form-control"  name="status" >
                        <option value="Pending">Pending</option>
                        <option value="Conform">Conform</option>
                        <option value="You are Not Eligible for this course">You are Not Eligible for this course</option>
                    </select>
                </div>

            </div>



            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button name="btn" class="btn btn-success btn-block">Application for Registration</button>
                </div>

            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('studentAdmin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>