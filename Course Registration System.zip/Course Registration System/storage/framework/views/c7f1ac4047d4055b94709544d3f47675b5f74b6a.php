<?php $__env->startSection('content'); ?>
<hr/>
<div class="row">
    <div class="col-lg-2"></div>
    <div class="col-lg-9">
        <h3 class="text-center text-success">Enter Student Information</h3>
        <h3 class="text-center text-success"><?php echo e(Session::get('massege')); ?></h3>
        <hr/>
        <div class="well">
            <?php echo Form::open(['url'=>'/student/save','method'=>'POST', 'class'=>'form-horizontal','enctype'=>'multipart/form-data']); ?>

            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Depertment</label>
                <div class="col-sm-10">
                    <select class="form-control" name="depertmentId">
                        <option>Select Depertment</option>
                        <?php $__currentLoopData = $depertment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $depertment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($depertment->id); ?>"><?php echo e($depertment->depertmentName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>  
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Student Id</label>
                <div class="col-sm-10">
                    <input type="text" name="studentId" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->has('studentId')?$errors->first('studentId'):""); ?> </span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Student Name</label>
                <div class="col-sm-10">
                    <input type="text" name="studentName" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->has('studentName')?$errors->first('studentName'):""); ?> </span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Father Name</label>
                <div class="col-sm-10">
                    <input type="text" name="fatherName" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->has('fatherName')?$errors->first('fatherName'):""); ?> </span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Mother Name</label>
                <div class="col-sm-10">
                    <input type="text" name="motherName" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->has('motherName')?$errors->first('motherName'):""); ?> </span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Date of Birth</label>
                <div class="col-sm-10">
                    <input type="text" name="DOBirth" class="form-control" placeholder="dd/mm/yy">
                    <span class="text-danger"> <?php echo e($errors->has('DOBirth')?$errors->first('DOBirth'):""); ?> </span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Address</label>
                <div class="col-sm-10">
                    <textarea class="form-control" name="address" rows="5"></textarea>
                    <span class="text-danger"><?php echo e($errors->has('address')?$errors->first('address'):''); ?></span>
                </div>

            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Phone No</label>
                <div class="col-sm-10">
                    <input type="text" name="phone" class="form-control" >
                    <span class="text-danger"> <?php echo e($errors->has('phone')?$errors->first('phone'):""); ?> </span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Relagion</label>
                <div class="col-sm-10">
                    <select class="form-control" name="relagion">
                        <option>Select Relagion</option>
                        <option value="islam">Islam</option>
                        <option value="hindu">Hindu</option>
                        <option value="other">Others</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Blood Group</label>
                <div class="col-sm-10">
                    <input type="text" name="blood" class="form-control" >
                    <span class="text-danger"> <?php echo e($errors->has('blood')?$errors->first('blood'):""); ?> </span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Nationality</label>
                <div class="col-sm-10">
                    <select class="form-control" name="country">
                        <option>Select Country</option>
                        <option value="Bangladesh">Bangladesh</option>
                        <option value="India">India</option>
                        <option value="Pakistan">Pakistan</option>
                    </select>
                </div>  
            </div>

            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Student Image</label>
                <div class="col-sm-10">
                    <input type="file" name="studentImage" accept="image/*" >
                    <span class="text-danger"> <?php echo e($errors->has('studentImage')?$errors->first('studentImage'):""); ?> </span>
                </div>

            </div>

            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Username</label>
                <div class="col-sm-10">
                    <input type="email" name="email" class="form-control" >
                    <span class="text-danger"> <?php echo e($errors->has('email')?$errors->first('email'):""); ?> </span>
                </div>
            </div>
            
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Password</label>
                <div class="col-sm-10">
                    <input type="password" name="password" class="form-control" >
                    <span class="text-danger"> <?php echo e($errors->has('password')?$errors->first('password'):""); ?> </span>
                </div>
            </div>
            


            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button name="btn" class="btn btn-success btn-block">Save Student Information</button>
                </div>

            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>