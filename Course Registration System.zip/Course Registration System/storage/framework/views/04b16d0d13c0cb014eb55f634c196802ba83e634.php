<?php $__env->startSection('mainContent'); ?>
<div class="banner1">
    <div class="w3_agileits_service_banner_info">
        <h2>Gallery</h2>
    </div>
</div>
<!-- //banner -->
<!-- Modal1 -->
<div class="modal fade" id="myModal2" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>

                <div class="signin-form profile">
                    <h3 class="agileinfo_sign">Sign In</h3>	
                    <div class="login-form">
                        <form action="#" method="post">
                            <input type="text" name="email" placeholder="E-mail" required="">
                            <input type="password" name="password" placeholder="Password" required="">
                            <div class="tp">
                                <input type="submit" value="Sign In">
                            </div>
                        </form>
                    </div>
                    <div class="login-social-grids">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-rss"></i></a></li>
                        </ul>
                    </div>
                    <p><a href="#" data-toggle="modal" data-target="#myModal3" > Don't have an account?</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- //Modal1 -->	
<!-- Modal2 -->
<div class="modal fade" id="myModal3" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>

                <div class="signin-form profile">
                    <h3 class="agileinfo_sign">Sign Up</h3>	
                    <div class="login-form">
                        <form action="#" method="post">
                            <input type="text" name="name" placeholder="Username" required="">
                            <input type="email" name="email" placeholder="Email" required="">
                            <input type="password" name="password" placeholder="Password" required="">
                            <input type="password" name="password" placeholder="Confirm Password" required="">
                            <input type="submit" value="Sign Up">
                        </form>
                    </div>
                    <p><a href="#"> By clicking register, I agree to your terms</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- //Modal2 -->	

<div class="contact">
    <div class="container">
        <h3 class="w3l_header w3_agileits_header">Our <span>Gallery</span></h3>
        <div class="inner_w3l_agile_grids-gal">
            <div class="col-md-4 gallery-grid gallery1">
                <a href="images/1.jpg" class="swipebox"><img src="<?php echo e(asset('public/frontEnd/')); ?>/images/1.jpg" class="img-responsive" alt="/">
                    <div class="textbox">
                        <h4>Mastering</h4>
                        <p><i class="fa fa-graduation-cap" aria-hidden="true"></i></p>

                    </div>
                </a>
            </div>
            <div class="col-md-4 gallery-grid gallery1">
                <a href="images/2.jpg" class="swipebox"><img src="<?php echo e(asset('public/frontEnd/')); ?>/images/2.jpg" class="img-responsive" alt="/">
                    <div class="textbox">
                        <h4>Mastering</h4>
                        <p><i class="fa fa-graduation-cap" aria-hidden="true"></i></p>

                    </div>
                </a>
            </div>
            <div class="col-md-4 gallery-grid gallery1">
                <a href="images/3.jpg" class="swipebox"><img src="<?php echo e(asset('public/frontEnd/')); ?>/images/3.jpg" class="img-responsive" alt="/">
                    <div class="textbox">
                        <h4>Mastering</h4>
                        <p><i class="fa fa-graduation-cap" aria-hidden="true"></i></p>

                    </div>
                </a>
            </div>
            <div class="col-md-4 gallery-grid gallery1">
                <a href="images/4.jpg" class="swipebox"><img src="<?php echo e(asset('public/frontEnd/')); ?>/images/4.jpg" class="img-responsive" alt="/">
                    <div class="textbox">
                        <h4>Mastering</h4>
                        <p><i class="fa fa-graduation-cap" aria-hidden="true"></i></p>

                    </div>
                </a>
            </div>
            <div class="col-md-4 gallery-grid gallery1">
                <a href="images/5.jpg" class="swipebox"><img src="<?php echo e(asset('public/frontEnd/')); ?>/images/5.jpg" class="img-responsive" alt="/">
                    <div class="textbox">
                        <h4>Mastering</h4>
                        <p><i class="fa fa-graduation-cap" aria-hidden="true"></i></p>

                    </div>
                </a>
            </div>
            <div class="col-md-4 gallery-grid gallery1">
                <a href="images/6.jpg" class="swipebox"><img src="<?php echo e(asset('public/frontEnd/')); ?>/images/6.jpg" class="img-responsive" alt="/">
                    <div class="textbox">
                        <h4>Mastering</h4>
                        <p><i class="fa fa-graduation-cap" aria-hidden="true"></i></p>
                    </div>
                </a>
            </div>
            <div class="col-md-4 gallery-grid gallery1">
                <a href="images/7.jpg" class="swipebox"><img src="<?php echo e(asset('public/frontEnd/')); ?>/images/7.jpg" class="img-responsive" alt="/">
                    <div class="textbox">
                        <h4>Mastering</h4>
                        <p><i class="fa fa-graduation-cap" aria-hidden="true"></i></p>
                    </div>
                </a>
            </div>
            <div class="col-md-4 gallery-grid gallery1">
                <a href="images/8.jpg" class="swipebox"><img src="<?php echo e(asset('public/frontEnd/')); ?>/images/8.jpg" class="img-responsive" alt="/">
                    <div class="textbox">
                        <h4>Mastering</h4>
                        <p><i class="fa fa-graduation-cap" aria-hidden="true"></i></p>
                    </div>
                </a>
            </div>
            <div class="col-md-4 gallery-grid gallery1">
                <a href="images/2.jpg" class="swipebox"><img src="<?php echo e(asset('public/frontEnd/')); ?>/images/2.jpg" class="img-responsive" alt="/">
                    <div class="textbox">
                        <h4>Mastering</h4>
                        <p><i class="fa fa-graduation-cap" aria-hidden="true"></i></p>

                    </div>
                </a>
            </div>

            <div class="clearfix"> </div>
        </div>
    </div>	
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('java'); ?>
<script type="text/javascript" src="<?php echo e(asset('public/frontEnd/')); ?>/js/move-top.js"></script>
<script type="text/javascript" src="<?php echo e(asset('public/frontEnd/')); ?>/js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
<!-- for bootstrap working -->
	<script src="<?php echo e(asset('public/frontEnd/')); ?>/js/bootstrap.js"></script>
<!-- //for bootstrap working -->
<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>