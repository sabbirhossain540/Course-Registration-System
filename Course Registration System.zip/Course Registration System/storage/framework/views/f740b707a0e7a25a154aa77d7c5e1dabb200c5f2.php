<div class="main_section_agile">
    <div class="container">
         <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        Daffodil University
                    </a>
                </div>

            
            </div>
    </nav>
    </div>
            <div class="w3_agile_banner_top">
                <div class="agile_phone_mail">
                    
                    <ul>
                        <li><i class="fa fa-phone" aria-hidden="true"></i>+8801775526435</li>
                        <li><i class="fa fa-envelope" aria-hidden="true"></i><a href="#">www.facebook.com/sabbirhossain308</a></li>
                    </ul>
                    <div class="clearfix"> </div>
                </div>
            </div>
            <div class="agileits_w3layouts_banner_nav">
                <nav class="navbar navbar-default">
                    <div class="navbar-header navbar-left">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <h1><a class="navbar-brand" href="<?php echo e(url('/')); ?>"><i>Daffodil</i><span>University</span></a></h1>
                    </div>
                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
                        <nav class="menu--iris">
                            <ul class="nav navbar-nav menu__list">
                                <li class="menu__item menu__item--current"><a href="<?php echo e(url('/')); ?>" class="menu__link">Home</a></li>
                                <li class="menu__item"><a href="<?php echo e(url('/Service')); ?>" class="menu__link">Services</a></li>
                                <li class="menu__item"><a href="<?php echo e(url('/Gallery')); ?>" class="menu__link">Gallery</a></li>
                                <li class="dropdown menu__item">
                                    <a href="#" class="dropdown-toggle menu__link" data-toggle="dropdown">Diu Portal <b class="caret"></b></a>
                                    <ul class="dropdown-menu agile_short_dropdown">
                                        <li><a href="<?php echo e(url('/home')); ?>">For Admin</a></li>
                                        <li><a href="<?php echo e(url('/forStudent')); ?>">For Student</a></li>
                                        <li><a href="<?php echo e(url('/tLogin')); ?>">For Teacher</a></li>
                                    </ul>
                                </li>
                                <li class="menu__item"><a href="<?php echo e(url('/Contact')); ?>" class="menu__link">Mail Us</a></li>
                            </ul>
                            <div class="w3_agileits_search">
                                <form action="#" method="post">
                                    <input type="search" name="Search" placeholder="Search here..." required="">
                                    <input type="submit" value=" ">
                                </form>
                            </div>
                        </nav>
                    </div>
                </nav>
            </div>
        </div>
