<?php $__env->startSection('content'); ?>
<hr/>
<div class="row">
    <div class="col-lg-1"></div>
    <div class="col-lg-10">
        <h3 class="text-center text-success"><?php echo e(Session::get('massege')); ?></h3>
        <hr/>
        <div class="well">
            <?php echo Form::open(['url'=>'/samister/update','method'=>'POST', 'class'=>'form-horizontal', 'name'=>'samisterEditForm']); ?>

            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Samister Name</label>
                <div class="col-sm-10">
                    <input type="text" name="samisterName" value="<?php echo e($samisterById->samisterName); ?>" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->has('samisterName')?$errors->first('samisterName'):""); ?> </span>
                    <input type="hidden" name="id" value="<?php echo e($samisterById->id); ?>" class="form-control">
                </div>

            </div>

            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Samister Description</label>
                <div class="col-sm-10">
                    <textarea class="form-control" name="samisterDescription" rows="8"><?php echo e($samisterById->samisterDescription); ?></textarea>
                    <span class="text-danger"><?php echo e($errors->has('samisterDescription')?$errors->first('samisterDescription'):''); ?></span>
                </div>

            </div>

            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Publication Status</label>
                <div class="col-sm-10">
                    <select class="form-control" name="publicationStatus">
                        <option>Select Publication Status</option>
                        <option value="1">Published</option>
                        <option value="0">Unpublished</option>
                    </select>
                </div>

            </div>

            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button name="btn" class="btn btn-info btn-block">Update Samister Information</button>
                </div>

            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<script>
    document.forms['samisterEditForm'].elements['publicationStatus'].value=<?php echo e($samisterById->publicationStatus); ?>

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>