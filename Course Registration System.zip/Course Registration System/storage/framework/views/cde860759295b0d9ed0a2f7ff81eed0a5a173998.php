<!DOCTYPE HTML>
<html>
    <head>
        <title>Teachers login for online Course Registration System</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Minimal Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
              Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
        <!-- Custom Theme files -->
        <link href="<?php echo e(asset('public/studentAdmin/')); ?>/css/style.css" rel='stylesheet' type='text/css' />
        <link href="<?php echo e(asset('public/studentAdmin/')); ?>/css/font-awesome.css" rel="stylesheet"> 
        <script src="<?php echo e(asset('public/studentAdmin/')); ?>/js/jquery.min.js"></script>
        <script src="<?php echo e(asset('public/studentAdmin/')); ?>/js/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="login">
            <h1><a href="<?php echo e(url('/')); ?>">Teacher Portal</a></h1>
            <div class="login-bottom">
                <h2 class="text-center">Login</h2>
                <h4 style="color: red;">
                <?php
                echo Session::get('massege');
                echo Session::put('massege');
                ?>
                </h4>
                <form method="POST" action="<?php echo e(url('/teacher/login')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="">
                        <div class="login-mail">
                            <input type="text" placeholder="Email" required="" name="username">
                            <i class="fa fa-envelope"></i>
                                                                        </div>
                                                                        <div class="login-mail">
                            <input type="password" placeholder="Password" required="" name="password">
                                                                            <i                                                                    class="fa fa-lock"></i>
                                                                                              </div>
                                                                                    <div class="login-do">
                                                                                        <label class="hvr-shutter-in-horizontal login-sub" >
                                <input type="submit" value="login">
                                                                                    </la                                                                                bel>
                    </div>
                    <div                                                                                    style="margin-top: 20px;">
                        <a cla                                                                                        ss="news-letter " href="#">
        <label class="checkbox1"><input type="checkbox" name="checkbox" ><i> </i>Forget Password</label>
</a>
</div>


</div>        


<div class="clearfix"> </d    iv>
</form>
</div>
        </div>
        <!---->
        <div class="copy-right">
<p> &copy; 2017 Online Course Registration System</a> </p>	    </div>  
<!---->
<!--scrolling js-->
<script src="<?php echo e(asset('public/teacherAdmin/')); ?>/js/jquery.nicescroll.js"></script>
<script src="<?php echo e(asset('public/teacherAdmin/')); ?>/js/scripts.js"></script>
<!--//scrolling js-->
</body>
</html>
