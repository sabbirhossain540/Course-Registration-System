<?php $__env->startSection('content'); ?>
<hr/>
<div class="row">
    <div class="col-lg-1"></div>
    <div class="col-lg-10">
        <h3 class="text-center text-success"><?php echo e(Session::get('massege')); ?></h3>
        <hr/>
        <div class="well">
            <?php echo Form::open(['url'=>'/shedule/update','method'=>'POST', 'class'=>'form-horizontal', 'name'=>'sheduleForm']); ?>

            <h3 class="text-center">Shedule Information</h3>
            <hr/>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Section</label>
                <div class="col-sm-10">
                    <input type="text" name="sectionName" value="<?php echo e($sheduleById->sectionName); ?>" class="form-control">
                    <input type="hidden" name="id" value="<?php echo e($sheduleById->id); ?>" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->has('sectionName')?$errors->first('sectionName'):""); ?> </span>
                </div>

            </div>
            
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Total Seat</label>
                <div class="col-sm-10">
                    <input type="number" name="seatNo" value="<?php echo e($sheduleById->seatNo); ?>" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->has('seatNo')?$errors->first('seatNo'):""); ?> </span>
                </div>

            </div>
            
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Class Room No</label>
                <div class="col-sm-10">
                    <input type="text" name="roomNo" value="<?php echo e($sheduleById->roomNo); ?>" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->has('roomNo')?$errors->first('roomNo'):""); ?> </span>
                </div>

            </div>
            
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Time Slot</label>
                <div class="col-sm-10">
                    <input type="text" name="timeSlot" value="<?php echo e($sheduleById->timeSlot); ?>" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->has('timeSlot')?$errors->first('timeSlot'):""); ?> </span>
                </div>

            </div>

            
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Publication Status</label>
                <div class="col-sm-10">
                    <select class="form-control" name="publicationStatus">
                        <option>Select Publication Status</option>
                        <option value="1">Published</option>
                        <option value="0">Unpublished</option>
                    </select>
                </div>

            </div>

            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button name="btn" class="btn btn-success btn-block">Update Shedule Information</button>
                </div>

            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<script>
  document.forms['sheduleForm'].elements['publicationStatus'].value=<?php echo e($sheduleById->publicationStatus); ?>

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>