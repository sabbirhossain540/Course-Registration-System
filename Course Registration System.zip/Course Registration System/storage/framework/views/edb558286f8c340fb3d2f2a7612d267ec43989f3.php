<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-2"></div>
    <div class="col-lg-10">
        <h3 class="text-center text-denger"><?php echo e(Session::get('massege')); ?></h3>
        <hr/>

        <div class="well">

            <h3 class="text-center text-success">Register Course List</h3>
            <hr/>
            <div class="col-lg-12" style="margin-bottom: 10px;">
                <form method="post" action="<?php echo e(url('/view/registerCourseBySemister')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <div>
                            <label for="inputEmail3" class="col-sm-2 control-label">

                                <select class="form-control" name="samisterName">
                                    <?php $__currentLoopData = $semister; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semister): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($semister->id); ?>"><?php echo e($semister->samisterName); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                            </label>
                        </div>
                        <div class="col-sm-1">
                            <button name="btn" class="btn btn-success btn-block">Search</button>
                        </div>

                    </div>

                </form>
            </div>

            <table class="table table-hover table-bordered">
                <thead>
                    <tr>


                        <th>Course Name</th>
                        <th>Samister</th>
                        <th>Status</th>

                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                        <td><?php echo e($course->samisterName); ?></td>
                        <td><?php echo e($course->courseName); ?></td>
                        <td><?php echo e($course->status); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('studentAdmin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>