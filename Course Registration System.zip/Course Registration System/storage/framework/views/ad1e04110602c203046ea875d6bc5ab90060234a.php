<!DOCTYPE HTML>
<html>
<head>
<title>Student Login for online Course Registration System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Modern Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!-- Bootstrap Core CSS -->
<link href="<?php echo e(asset('public/Sadmin/')); ?>/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="<?php echo e(asset('public/Sadmin/')); ?>/css/style.css" rel='stylesheet' type='text/css' />
<link href="<?php echo e(asset('public/Sadmin/')); ?>/css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<script src="<?php echo e(asset('public/Sadmin/')); ?>/js/jquery.min.js"></script>
<!----webfonts--->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900' rel='stylesheet' type='text/css'>
<!---//webfonts--->  
<!-- Bootstrap Core JavaScript -->
<script src="<?php echo e(asset('public/Sadmin/')); ?>/js/bootstrap.min.js"></script>
</head>
<body id="login">
  <div class="login-logo">
      <h2 class="form-heading text-center"><a href="<?php echo e(url('/')); ?>">DIU</a></h2>
  </div>
  <h2 class="form-heading">STUDENT LOGIN</h2>
  <div class="app-cam">
      <h4 style="color: red;">
          <?php
            echo Session::get('massege');
            echo Session::put('massege');
          ?>
      </h4>
	  <form role="form" method="POST" action="<?php echo e(url('/Student/login')); ?>">
           <?php echo e(csrf_field()); ?>

		<input type="text" class="text" name="username" placeholder="Username"}">
		<input type="password" value="Password" name="password" placeholder="Password"}">
		<div class="submit"><input class="btn btn-success btn-block"  name="btn" type="submit" value="Login"></div>
		
		<ul class="new">
			<li class="new_left"><p><a href="#">Forgot Password ?</a></p></li>
			
			<div class="clearfix"></div>
		</ul>
	</form>
  </div>
   <div class="copy_layout login">
      <p>Copyright &copy; 2017 Online Course Registration System </a> </p>
   </div>
</body>
</html>