<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/','WelcomeController@index');
Route::get('/Service','WelcomeController@service');

Route::get('/Gallery','WelcomeController@gallery');
Route::get('/Contact','WelcomeController@contact');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');




//                                                      ADMIN PANEL DEVELOPMENT

//Depertment Info

Route::get('/depertment/add','DepertmentController@addDepertment');
Route::post('/depertment/save','DepertmentController@storeDepertment');
Route::get('/depertment/manage','DepertmentController@manageDepertment');
Route::get('/depertment/edit/{id}','DepertmentController@editDepertment');
Route::post('/depertment/update','DepertmentController@updateDepertment');
Route::get('/depertment/delete/{id}','DepertmentController@deleteDepertment');


//Subject Info 

Route::get('/subject/add','SubjectController@addSubject');
Route::post('/subject/save','SubjectController@storeSubject');
Route::get('/subject/manage','SubjectController@manageSubject');
Route::get('/subject/edit/{id}','SubjectController@editSubject');
Route::post('/subject/update','SubjectController@updateSubject');
Route::get('/subject/delete/{id}','SubjectController@deleteSubject');

//Samister information

Route::get('/samister/add','SamisterController@addSamister');
Route::post('/samister/save','SamisterController@storeSamister');
Route::get('/samister/manage','SamisterController@manageSamister');
Route::get('/samister/edit/{id}','SamisterController@editSamister');
Route::post('/samister/update','SamisterController@updateSamister');
Route::get('/samister/delete/{id}','SamisterController@deleteSamister');

// Shedule Manage Information

Route::get('/shedule/add','SheduleController@addShedule');
Route::post('/shedule/save','SheduleController@storeShedule');
Route::get('/shedule/manage','SheduleController@manageShedule');
Route::get('/shedule/edit/{id}','SheduleController@editShedule');
Route::post('/shedule/update','SheduleController@updateShedule');
Route::get('/shedule/delete/{id}','SheduleController@deleteShedule');
Route::get('/student/add','SheduleController@addStudent');

//Course Related Information
Route::get('/course/add','courseController@addCourse');
Route::post('/course/save','courseController@storeCourse');
Route::get('/course/manage','courseController@manageCourse');
Route::get('/course/edit/{id}','courseController@editCourse');
Route::post('/course/update','courseController@updateCourse');

// Payment Related information

Route::get('/payment/add','paymentController@index');
Route::post('/payment/save','paymentController@storePayment');
Route::get('/payment/manage','paymentController@paymentManage');
Route::get('/payment/edit/{id}','paymentController@editPayment');
Route::post('/payment/update','paymentController@updatePayment');
Route::get('/payment/delete/{id}','paymentController@deletePayment');



// Student Information
Route::get('/student/add','studentController@addStudent');
Route::post('/student/save','studentController@storeStudent');
Route::get('/student/manage','studentController@manageStudent');
Route::get('/samister/view/{id}','studentController@viewStudentInfo');
Route::get('/samister/edit/{id}','studentController@editStudent');
Route::post('/student/update','studentController@updateStudent');
Route::get('/samister/delete/{id}','studentController@deleteStudent');

//                                                  STUDENT ADMIN PANEL

Route::get('/forStudent','studentAdminController@index');
Route::post('/Student/login','studentAdminController@studentLogin');
Route::get('/Dashbord','studentAdminController@dashboard');
Route::get('/logout','studentAdminController@logout');
Route::get('/student/edit','studentAdminController@editProfile');
Route::post('/student/update','studentAdminController@updateStudent');


//                                                 Course Related
Route::get('/view/courseDetails','studentAdminController@viewCourseDetails');
Route::get('/course/registration','studentAdminController@paymentLogin');
Route::post('/registrationPage','studentAdminController@registerLogin');
Route::get('/view/registerTaken','studentAdminController@courseRegister');

Route::post('/registerCourse/save','studentAdminController@storeCourseInformation');
Route::get('/view/registerCourse','studentAdminController@viewRegisterCourse');
Route::post('/view/registerCourse','studentAdminController@viewRegisterCourse');
Route::post('/view/registerCourseBySemister','studentAdminController@registerCourseBySemister');



//___________________________________ TEACHER ADMIN PANEL DESIGN_____________________________________________________


Route::get('/teacher/add','teacherController@addTeacher');
Route::post('/teacher/save','teacherController@storeTeacher');
Route::get('/teacher/manage','teacherController@manageTeacher');
Route::get('/teacher/view/{id}','teacherController@viewTeacherInfo');
Route::get('/teacher/edit/{id}','teacherController@editTeacher');
Route::post('/teacher/update','teacherController@updateTeacher');
Route::get('/teacher/delete/{id}','teacherController@deleteTeacher');


//------------------------------------ Main Panel Teacher ------------------------------------------------

Route::get('/tLogin','teacherAdminController@index');
Route::post('/teacher/login','teacherAdminController@teacherLogin');
Route::get('/teacherDashbord','teacherAdminController@teacherDashboard');
Route::get('/teacherLogout','teacherAdminController@teacherLogout');
Route::get('/teacher/edit','teacherAdminController@editteacherProfile');
Route::post('/teacher/update','teacherAdminController@updateTeacher');
Route::get('teacher/studentView','teacherAdminController@manageStudentInformation');
Route::get('/studentInformation/view/{id}','teacherAdminController@viewStudentInformation');
Route::get('/studentInformation/course/{id}','teacherAdminController@courseInformation');

// Course Related

Route::get('/viewPendingCourse','teacherAdminController@viewPendingCourse');
Route::get('/pendingCourse/edit/{id}','teacherAdminController@editPending');
Route::post('/editPending/save','teacherAdminController@updatePendingCourse');
Route::get('/pendingCourse/delete/{id}','teacherAdminController@deletePending');

