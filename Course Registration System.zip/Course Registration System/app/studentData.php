<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class studentData extends Model
{
    
}
