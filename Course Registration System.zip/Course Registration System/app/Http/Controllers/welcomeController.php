<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class welcomeController extends Controller
{
    public function index(){
        return view('frontEnd.home.homeContent');
    }
    
    public function service(){
        return view('frontEnd.home.serviceContent');
    }
    
    public function gallery(){
        return view('frontEnd.home.gallery');
    }
    public function contact(){
        return view('frontEnd.home.contact');
    }
    
    public function studentLogin(){
        return view('Sadmin.login.login');
    }
    
    public function teacherLogin(){
        return view('teacherLogin.login.login');
    }
    
    
}
