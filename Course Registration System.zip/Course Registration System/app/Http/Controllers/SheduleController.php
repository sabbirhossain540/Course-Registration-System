<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Shedule;

class SheduleController extends Controller
{
    public function addShedule(){
        return view('admin.shedule.createShedule');
    }
    
    public function storeShedule(Request $request){
        $this->validate($request,[
            'sectionName' => 'required',
            'seatNo' => 'required',
            'roomNo' => 'required',
            'timeSlot' => 'required',
        ]);
        
        $shedule = new Shedule;
        $shedule->sectionName = $request->sectionName;
        $shedule->seatNo = $request->seatNo;
        $shedule->roomNo = $request->roomNo;
        $shedule->timeSlot = $request->timeSlot;
        $shedule->publicationStatus = $request->publicationStatus;
        $shedule->save();
        return redirect('/shedule/add')->with('massege','Shedule Info Save Successfully');
    }
    
    public function manageShedule(){
        $shedule = Shedule::all();
        return view('admin.shedule.manageShedule',['shedule'=>$shedule]);
    }
    
    public function editshedule($id){
        $sheduleById = Shedule::where('id',$id)->first();
        return view('admin.shedule.editShedule',['sheduleById'=>$sheduleById]);
    }
    
    public function updateShedule(Request $request){
        $shedule = Shedule::find($request->id);
        $shedule->sectionName = $request->sectionName;
        $shedule->seatNo = $request->seatNo;
        $shedule->roomNo = $request->roomNo;
        $shedule->timeSlot = $request->timeSlot;
        $shedule->publicationStatus = $request->publicationStatus;
        $shedule->save();
        return redirect('/shedule/manage')->with('massege','Shedule Info Update Successfully');
    }
    
    public function deleteShedule($id){
        $shedule = Shedule::find($id);
        $shedule->delete();
        return redirect('/shedule/manage')->with('massege','Shedule Info Delete Successfully');
    }
    
    public function addStudent(){
        return view('admin.student.student');
    }
}
