<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Samister;

class SamisterController extends Controller
{
    public function addSamister(){
        return view('admin.samister.createsamister');
    }
    
    public function storeSamister(Request $request){
        $samister = new Samister;
        $samister->samisterName = $request->samisterName;
        $samister->samisterDescription = $request->samisterDescription;
        $samister->publicationStatus = $request->publicationStatus;
        $samister->save();
        return redirect('/samister/add')->with('massege','Samister Info Save Successfully');
    }
    
    public function manageSamister(){
        $samister = Samister::all();
        return view('admin.samister.manageSamister',['samister'=>$samister]);
    }
    
    public function editSamister($id){
        $samisterById = Samister::where('id',$id)->first();
        return view('admin.samister.editSamister',['samisterById'=>$samisterById]);
    }
    
    public function updateSamister(Request $request){
        $samister = Samister::find($request->id);
        $samister->samisterName = $request->samisterName;
        $samister->samisterDescription = $request->samisterDescription;
        $samister->publicationStatus = $request->publicationStatus;
        $samister->save();
        return redirect('/samister/manage')->with('massege','Samister Info Update Successfully');
        
    }
    
    public function deleteSamister($id){
        $samister = Samister::find($id);
        $samister->delete();
        return redirect('/samister/manage')->with('massege','Samister Info Delete Successfully');
    }
}
