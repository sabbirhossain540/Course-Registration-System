<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Subject;

class SubjectController extends Controller
{
    public function addSubject(){
        return view('admin.subject.createSubject');
    }
    
    public function storeSubject(Request $request){
        $this->validate($request,[
            'subjectName' => 'required',
            'subjectDescription' => 'required',
        ]);
        $subject = new Subject;
        $subject->subjectName = $request->subjectName;
        $subject->subjectDescription = $request->subjectDescription;
        $subject->publicationStatus = $request->publicationStatus;
        $subject->save();
        return redirect('/subject/add')->with('massege','Subject Info Save Successfully');
    }
    
    public function manageSubject(){
        $subject = Subject::all();
        return view('admin.subject.manageSubject',['subject'=>$subject]);
    }
    
    public function editSubject($id){
        $subjectById = Subject::where('id',$id)->first();
        return view('admin.subject.editSubject',['subjectById'=>$subjectById]);
    }
    
    public function updateSubject(Request $request){
        $subject = Subject::find($request->id);
        $subject->subjectName = $request->subjectName;
        $subject->subjectDescription = $request->subjectDescription;
        $subject->publicationStatus = $request->publicationStatus;
        $subject->save();
        return redirect('/subject/manage')->with('massege','Subject Info Update Successfully');
    }
    
    public function deleteSubject($id){
        $subject = Subject::find($id);
        $subject->delete();
        return redirect('/subject/manage')->with('massege','Subject Info Delete Successfully');
    }
}
