<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Response;
use Illuminate\Http\Request;
use App\Depertment;
use App\teacherData;
use App\course;
use Illuminate\Support\Facades\DB;

class courseController extends Controller {

    public function addCourse() {
        $depertment = Depertment::where('publicationStatus', 1)->get();

        $teacher = teacherData::all();
        /*
          echo '<pre>';
          print_r($teacher);
          echo '</pre>';
          exit();
         * */


        return view('admin.course.createCourse', ['depertment' => $depertment, 'teacher' => $teacher,]);
    }

    public function storeCourse(Request $request){
        $course = new course();
        $course->courseCode = $request->courseCode;
        $course->courseName = $request->courseName;
        $course->depertmentName = $request->depertmentName;
        $course->courseInstructor = $request->courseInstructor;
        $course->section = $request->section;
        $course->seatNo = $request->seatNo;
        $course->publicationStatus = $request->publicationStatus;
        $course->save();
        
        return redirect('/course/add')->with('massege','Course Info Save Successfully');
    }
    
    public function manageCourse(){
        //return view('admin.course.manageCourse');
        $course = DB::table('courses')
                ->join('depertments','courses.depertmentName','=','depertments.id')
                ->join('teacher_datas','courses.courseInstructor','=','teacher_datas.id')
                ->select('courses.*','depertments.depertmentName','teacher_datas.teacherName')
                ->get();
        
        return view('admin.course.manageCourse',['course'=>$course]);
        
 
    }
    
    public function editCourse($id){
        $depertment = Depertment::where('publicationStatus', 1)->get();

        $teacher = teacherData::all();
        
        $courseById = course::where('id',$id)->first();
        return view('admin.course.editCourse',['courseById'=>$courseById, 'depertment'=>$depertment, 'teacher'=>$teacher]);
    }
    
    
    public function updateCourse(Request $request){
        $course = course::find($request->id);
        $course->courseCode = $request->courseCode;
        $course->courseName = $request->courseName;
        $course->depertmentName = $request->depertmentName;
        $course->courseInstructor = $request->courseInstructor;
        $course->section = $request->section;
        $course->seatNo = $request->seatNo;
        $course->publicationStatus = $request->publicationStatus;
        $course->save();
        
        return redirect('/course/manage')->with('massege','Course Info Update Successfully');
    }

}
