<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\payment;
use App\Samister;
use Illuminate\Support\Facades\DB;

class paymentController extends Controller
{
    public function index(){
        $samister = Samister::where('publicationStatus', 1)->get();
        return view('admin.payment.addPayment',['samister'=>$samister]);
    }
    
    public function storePayment(Request $request){
        $payment = new payment();
        $payment->studentId = $request->studentId;
        $payment->paymentNo = $request->paymentNo;
        $payment->samisterName = $request->samisterName;
        $payment->save();
        
        return redirect('/payment/add')->with('massege','payment Info Save Successfully');
    }
    
    public function paymentManage(){
        $payment = DB::table('payments')
                ->join('samisters','payments.samisterName','=','samisters.id')
                ->select('payments.*','samisters.samisterName')
                ->get();
        return view('admin.payment.managePayment',['payment'=>$payment]);
        
    }
    
    public function editPayment($id){
        $payment = payment::where('id',$id)->first();
        $samister = Samister::where('publicationStatus', 1)->get();
        return view('admin.payment.editPayment',['payment'=>$payment,'samister'=>$samister]);
    }
    
    public function updatePayment(Request $request){
        $payment = payment::find($request->id);
        $payment->studentId = $request->studentId;
        $payment->paymentNo = $request->paymentNo;
        $payment->samisterName = $request->samisterName;
        $payment->save();
        
        return redirect('/payment/manage')->with('massege','payment Info Update Successfully');
    }
    
    public function deletePayment($id){
        $payment = payment::find($id);
        $payment->delete();
        return redirect('/payment/manage')->with('massege','Student Payment Info Delete Successfully');
    }
}
