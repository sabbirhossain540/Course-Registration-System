<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\teacherData;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use App\Depertment;
use App\studentData;
use App\registerCourse;


class teacherAdminController extends Controller
{
    public function index(){
        $this->login_Auth();
        return view('teacherAdmin.login.login');
    }
    
   public function teacherLogin(Request $request){
       $username = $request->username;
       $password = $request->password;
       
       $users = DB::table('teacher_datas')
            ->where('email',$username )
            ->Where('password',$password)
            ->first();
       
       if($users){
            Session::put('id',$users->id);
            Session::put('teacherId',$users->teacherId);
            Session::put('depertmentId',$users->depertmentId);
            Session::put('teacherName',$users->teacherName);
            return redirect('/teacherDashbord');
       }else{
           Session::put('massege','Your Username or Password Invalid!!');
           return redirect('/tLogin');
       }
   }
   
   public function teacherDashboard(){
       
       $this->logout_auth();
       
       $id = Session::get('id');
        
        $teacher = DB::table('teacher_datas')
                ->join('depertments','teacher_datas.depertmentid','=','depertments.id')
                ->select('teacher_datas.*','depertments.depertmentName')
                ->where('teacher_datas.id',$id)
                ->first();
        
        
        return view('teacherAdmin.home.homeContent',['teacher'=>$teacher]);
   }
   
   
   
   public function teacherLogout(){
        Session::put('id','');
        Session::put('teacherId','');
        Session::put('teacherName','');
        Session::put('massege','You are Successfully Logout');
        return redirect('/tLogin');
    }
    
    
    
    public function login_auth(){
        session_start();
        $id = Session::get('id');
        if($id != NULL){
            return redirect('/teacherDashbord')->send();
        }
    }
    
    
    public function logout_auth(){
        session_start();
        $id = Session::get('id');
        if($id == NULL){
            return redirect('/tLogin')->send();
    }
    }
    
    
    
    
    public function editteacherProfile(){
        $id = Session::get('id');
        $depertment = Depertment::where('publicationStatus', 1)->get();
        $teacherById = teacherData::where('id',$id)->first();
        return view('teacherAdmin.home.editTeacher',['teacherById'=>$teacherById, 'depertment'=>$depertment]);
    }
    
    
     public function updateTeacher(Request $request){
        $imageUrl = $this->imageExistStatus($request);
        $id = Session::get('id');
        $teacher = teacherData::find($request->id);
        
 
        $teacher->fatherName = $request->fatherName;
        $teacher->motherName = $request->motherName;
        $teacher->DOBirth = $request->DOBirth;
        $teacher->address = $request->address;
        $teacher->phone = $request->phone;
        $teacher->relagion = $request->relagion;
        $teacher->blood = $request->blood;
        $teacher->country = $request->country;
        $teacher->teacherImage = $imageUrl;
        
        $teacher->password = $request->password;
        $teacher->save();
        return redirect('/teacherDashbord')->with('massege','Teacher Info Update Successfully');
    }
    
     private function imageExistStatus($request){
        $teacherById = teacherData::where('id',$request->id)->first();
        $teacherImage = $request->file('teacherImage');
        if($teacherImage){
            
            $name = $teacherImage->getClientOriginalName();
            $uploadPath = 'public/teacherImage/';
            $teacherImage->move($uploadPath, $name);
            $imageUrl = $uploadPath.$name;
        }else{
           
            $imageUrl = $teacherById->teacherImage;
        }
        return $imageUrl;
    }
    
    
    public function manageStudentInformation(){
        $depertment = Session::get('depertmentId');
        $student = DB::table('student_datas')
                ->join('depertments','student_datas.depertmentid','=','depertments.id')
                ->select('student_datas.*','depertments.depertmentName')
                ->where('depertmentId',$depertment)
                ->get();
       
        
        return view('teacherAdmin.studentInformation.manageStudent',['student'=>$student]);
    }
    
    
    public function viewStudentInformation($id){
        $student = DB::table('student_datas')
                ->join('depertments','student_datas.depertmentid','=','depertments.id')
                ->select('student_datas.*','depertments.depertmentName')
                ->where('student_datas.id',$id)
                ->first();
        
        return view('teacherAdmin.studentInformation.viewStudentInformation',['student'=>$student]);
    }
    
    
    public function courseInformation($id){
        
        $depertment = Session::get('depertmentId');
        
       
        $studentId = DB::table('student_datas')
                ->select('student_datas.studentId')
                ->where('student_datas.id',$id)
                //->where('student_datas.id',$id)
                ->first();
        
            
        $courseInformation = DB::table('register_courses')
                ->join('courses','register_courses.courseName','=','courses.id')
                ->join('student_datas','register_courses.studentId','=','student_datas.studentId')
                ->join('depertments','register_courses.depermentName','=','depertments.id')
                ->join('samisters','register_courses.samisterName','=','samisters.id')
                ->select('register_courses.*','depertments.id','samisters.samisterName','courses.courseName','register_courses.id','student_datas.studentId')
                ->where('depertments.id',$depertment)
                ->where('register_courses.studentId',$studentId->studentId)
                ->where('register_courses.status','Conform')
               
                ->get();
 
        return view('teacherAdmin.studentInformation.completeCourse',['courseInformation'=>$courseInformation]);
            
    }
    
    
    public function viewPendingCourse(){
        $depertment = $id = Session::get('depertmentId');
        
        $pendingCourse = DB::table('register_courses')
                ->join('courses','register_courses.courseName','=','courses.id')
                ->join('depertments','register_courses.depermentName','=','depertments.id')
                ->join('samisters','register_courses.samisterName','=','samisters.id')
                ->select('register_courses.*','depertments.id','samisters.samisterName','courses.courseName','register_courses.id')
                ->where('depertments.id',$depertment)
                ->where('register_courses.status','Pending')
                ->orwhere('register_courses.status','You are Not Eligible for this course')
                ->get();
       
        
        
        
         
        
        return view('teacherAdmin.course.viewPendingCourse',['pendingCourse'=>$pendingCourse]);
    }
    
    
    public function editPending($id){
        
        $editPendingCourse = DB::table('register_courses')
                ->join('courses','register_courses.courseName','=','courses.id')
                ->join('depertments','register_courses.depermentName','=','depertments.id')
                ->join('samisters','register_courses.samisterName','=','samisters.id')
                ->select('register_courses.*','depertments.id','samisters.samisterName','courses.courseName','register_courses.id')
                ->where('register_courses.id',$id)
                ->first();
        
       /* 
        $editPendingCourse = registerCourse::where('id',$id)->first();
                
        echo '<pre>';
        print_r($editPendingCourse);
        echo '</pre>';
        exit();
        
       */ 
        return view('teacherAdmin.course.editPendingCourse',['editPendingCourse'=>$editPendingCourse]);
         
    }
    
    public function updatePendingCourse(Request $request){
        
        $pendingCourse = registerCourse::find($request->id);
        $pendingCourse->status = $request->status;
        $pendingCourse->save();
        return redirect('/viewPendingCourse')->with('massege','Conform Course Successfully');
        
    }
    
    public function deletePending($id){
        echo $id;
    }












    /*
     *
     */
}
