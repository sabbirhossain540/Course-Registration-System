<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Depertment;
use App\teacherData;
use Illuminate\Support\Facades\DB;




class teacherController extends Controller
{
    
    
    public function addTeacher(){
        $depertment = Depertment::where('publicationStatus', 1)->get();
        return view('admin.teacher.teacher',['depertment'=>$depertment]);
    }
    
    public function storeTeacher(Request $request){
        $teacherImage = $request->file('teacherImage');
        $name = $teacherImage->getClientOriginalName();
        $uploadPath = 'public/teacherImage/';
        $teacherImage->move($uploadPath, $name);
        $imageUrl = $uploadPath . $name;
        $this->saveProductInfo($request, $imageUrl);
        return redirect('/teacher/add')->with('massege','Teacher Info Add Successfully');
    }
    
    public function saveProductInfo($request, $imageUrl){
        
        
        $teacher = new teacherData();
         
        $teacher->depertmentId = $request->depertmentId;
        $teacher->teacherId = $request->teacherId;
        $teacher->teacherName = $request->teacherName;
        $teacher->dasingnation = $request->dasingnation;
        $teacher->fatherName = $request->fatherName;
        $teacher->motherName = $request->motherName;
        $teacher->DOBirth = $request->DOBirth;
        $teacher->address = $request->address;
        $teacher->phone = $request->phone;
        $teacher->relagion = $request->relagion;
        $teacher->blood = $request->blood;
        $teacher->country = $request->country;
        $teacher->teacherImage = $imageUrl;
        $teacher->email = $request->email;
        $teacher->password = $request->password;
        $teacher->save();
        return redirect('/teacher/add')->with('massege','Student Info Add Successfully');
         
    }
    
    public function manageTeacher(){
        $teacher = DB::table('teacher_datas')
                ->join('depertments','teacher_datas.depertmentid','=','depertments.id')
                ->select('teacher_datas.*','depertments.depertmentName')
                ->get();
        
        return view('admin.teacher.manageTeacher',['teacher'=>$teacher]);
    }
    
    public function viewTeacherInfo($id){
        $teacher = DB::table('teacher_datas')
                ->join('depertments','teacher_datas.depertmentid','=','depertments.id')
                ->select('teacher_datas.*','depertments.depertmentName')
                ->where('teacher_datas.id',$id)
                ->first();
        
        return view('admin.teacher.viewTeacherData',['teacher'=>$teacher]);
    }
    
    public function editTeacher($id){
        $depertment = Depertment::where('publicationStatus', 1)->get();
        $teacherById = teacherData::where('id',$id)->first();
        return view('admin.teacher.editTeacher',['teacherById'=>$teacherById, 'depertment'=>$depertment]);
    }
    
    
    public function updateTeacher(Request $request){
        $imageUrl = $this->imageExistStatus($request);
        
        $teacher = teacherData::find($request->id);
        
        
         
        $teacher->depertmentId = $request->depertmentId;
        $teacher->teacherId = $request->teacherId;
        $teacher->teacherName = $request->teacherName;
        $teacher->dasingnation = $request->dasingnation;
        $teacher->fatherName = $request->fatherName;
        $teacher->motherName = $request->motherName;
        $teacher->DOBirth = $request->DOBirth;
        $teacher->address = $request->address;
        $teacher->phone = $request->phone;
        $teacher->relagion = $request->relagion;
        $teacher->blood = $request->blood;
        $teacher->country = $request->country;
        $teacher->teacherImage = $imageUrl;
        $teacher->email = $request->email;
        $teacher->password = $request->password;
        $teacher->save();
        return redirect('/teacher/add')->with('massege','Teacher Info Update Successfully');
        
        
    }
    
    private function imageExistStatus($request){
        $teacherById = teacherData::where('id',$request->id)->first();
        $teacherImage = $request->file('teacherImage');
        if($teacherImage){
            
            $name = $teacherImage->getClientOriginalName();
            $uploadPath = 'public/teacherImage/';
            $teacherImage->move($uploadPath, $name);
            $imageUrl = $uploadPath.$name;
        }else{
           
            $imageUrl = $teacherById->teacherImage;
        }
        return $imageUrl;
    }
    
    
    public function deleteTeacher($id){
        $student = teacherData::find($id);
        $student->delete();
        return redirect('/teacher/manage')->with('massege','Student Info Delete Successfully');
    }
    
    
}
