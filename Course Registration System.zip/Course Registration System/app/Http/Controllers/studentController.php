<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Depertment;
use App\studentData;

use DB;


class studentController extends Controller
{
    public function addStudent(){
        $depertment = Depertment::where('publicationStatus', 1)->get();
        return view('admin.student.student',['depertment'=>$depertment]);
    }
    
    
    public function storeStudent(Request $request) {
        //return $request->all();
       
        // Use for Image upload
        $studentImage = $request->file('studentImage');
        $name = $studentImage->getClientOriginalName();
        $uploadPath = 'public/studentImage/';
        $studentImage->move($uploadPath, $name);
        $imageUrl = $uploadPath . $name;
        $this->saveProductInfo($request, $imageUrl);
        return redirect('/student/add')->with('massege','Student Info Add Successfully');
    }
    
  //  DB::table('categories')->insert([
//         'categoryName'=>$request->categoryName,
//           'categoryDescription'=>$request->categoryDescription,
//           'publication_status'=>$request->publication_status,
//       ]);
//       
//       return "Category information Save Successfully..";

    
    public function saveProductInfo($request, $imageUrl){
        
        
        $student = new studentData();
         
        $student->depertmentId = $request->depertmentId;
        $student->studentId = $request->studentId;
        $student->studentName = $request->studentName;
        $student->fatherName = $request->fatherName;
        $student->motherName = $request->motherName;
        $student->DOBirth = $request->DOBirth;
        $student->address = $request->address;
        $student->phone = $request->phone;
        $student->relagion = $request->relagion;
        $student->blood = $request->blood;
        $student->country = $request->country;
        $student->studentImage = $imageUrl;
        $student->email = $request->email;
        $student->password = $request->password;
        $student->save();
        return redirect('/student/add')->with('massege','Student Info Add Successfully');
         
    }
    
    public function manageStudent(){
        $student = DB::table('student_datas')
                ->join('depertments','student_datas.depertmentid','=','depertments.id')
                ->select('student_datas.*','depertments.depertmentName')
                ->get();
        
        return view('admin.student.manageStudent',['student'=>$student]);
        
        
    }
    
    public function viewStudentInfo($id){
        $student = DB::table('student_datas')
                ->join('depertments','student_datas.depertmentid','=','depertments.id')
                ->select('student_datas.*','depertments.depertmentName')
                ->where('student_datas.id',$id)
                ->first();
        
        return view('admin.student.viewStudent',['student'=>$student]);
    }
    
    public function editStudent($id){
        $depertment = Depertment::where('publicationStatus', 1)->get();
        $studentById = studentData::where('id',$id)->first();
        return view('admin.student.editStudent',['studentById'=>$studentById, 'depertment'=>$depertment]);
    }
    
    
    public function updateStudent(Request $request){
        $imageUrl = $this->imageExistStatus($request);
        
        $student = studentData::find($request->id);
        
        
         
        $student->depertmentId = $request->depertmentId;
        $student->studentId = $request->studentId;
        $student->studentName = $request->studentName;
        $student->fatherName = $request->fatherName;
        $student->motherName = $request->motherName;
        $student->DOBirth = $request->DOBirth;
        $student->address = $request->address;
        $student->phone = $request->phone;
        $student->relagion = $request->relagion;
        $student->blood = $request->blood;
        $student->country = $request->country;
        $student->studentImage = $imageUrl;
        $student->email = $request->email;
        $student->password = $request->password;
        $student->save();
        return redirect('/student/add')->with('massege','Student Info Update Successfully');
    }
    
    private function imageExistStatus($request){
        $studentById = studentData::where('id',$request->id)->first();
        $studentImage = $request->file('studentImage');
        if($studentImage){
            
            $name = $studentImage->getClientOriginalName();
            $uploadPath = 'public/studentImage/';
            $studentImage->move($uploadPath, $name);
            $imageUrl = $uploadPath.$name;
        }else{
           
            $imageUrl = $studentById->studentImage;
        }
        return $imageUrl;
    }
    
    
    
     public function deleteStudent($id){
        $student = studentData::find($id);
        $student->delete();
        return redirect('/samister/manage')->with('massege','Student Info Delete Successfully');
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
}
