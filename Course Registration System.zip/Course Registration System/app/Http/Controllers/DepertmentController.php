<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Depertment;

class DepertmentController extends Controller
{
    public function addDepertment(){
        return view('admin.depertment.createDepertment');
    }
    
    public function storeDepertment(Request $request){
        //return $request->all();
        $this->validate($request,[
            'depertmentName' => 'required',
            'depertmentDescription' => 'required',
        ]);
        $depertment = new Depertment;
        $depertment->depertmentName = $request->depertmentName;
        $depertment->depertmentDescription = $request->depertmentDescription;
        $depertment->publicationStatus = $request->publicationStatus;
        $depertment->save();
        return redirect('/depertment/add')->with('massege','Depertment Info Save Successfully');
    }
    
    public function manageDepertment(){
        $depertment = Depertment::all();
        return view('admin.depertment.manageDepertment',['depertment'=>$depertment]);
    }
    
    public function editDepertment($id){
        $depertmentById = Depertment::where('id',$id)->first();
        return view('admin.depertment.editDepertment',['depertmentById'=>$depertmentById]);
    }
    
    public function updateDepertment(Request $request){
        $depertment = Depertment::find($request->id);
        $depertment->depertmentName = $request->depertmentName;
        $depertment->depertmentDescription = $request->depertmentDescription;
        $depertment->publicationStatus = $request->publicationStatus;
        $depertment->save();
        
        return redirect('/depertment/manage')->with('massege','Depertment Info Update Successfully');
    }
    
    public function deleteDepertment($id){
        $depertment = Depertment::find($id);
        $depertment->delete();
        return redirect('/depertment/manage')->with('massege','Depertment Info Delete Successfully');
    }
}
