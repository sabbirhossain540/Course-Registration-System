<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use App\Depertment;
use App\studentData;
use App\Samister;
use App\course;
use App\registerCourse;

//use App\studentData;

class studentAdminController extends Controller {

    public function index() {
        $this->login_auth();

        return view('studentAdmin.login.login');
    }

    public function studentLogin(Request $request) {
        $username = $request->username;
        $password = $request->password;


        $users = DB::table('student_datas')
                ->where('email', $username)
                ->Where('password', $password)
                ->first();


        if ($users) {
            Session::put('id', $users->id);
            Session::put('studentId', $users->studentId);
            Session::put('depertmentId', $users->depertmentId);
            Session::put('studentName', $users->studentName);
            return redirect('/Dashbord');
        } else {
            Session::put('massege', 'Your Username or Password Invalid!!');
            return redirect('/forStudent');
        }
    }

    public function login_auth() {
        session_start();
        $id = Session::get('id');
        if ($id != NULL) {
            return redirect('/Dashbord')->send();
        }
    }

    public function dashboard() {
        $this->logout_auth();

        $id = Session::get('id');

        $student = DB::table('student_datas')
                ->join('depertments', 'student_datas.depertmentid', '=', 'depertments.id')
                ->select('student_datas.*', 'depertments.depertmentName')
                ->where('student_datas.id', $id)
                ->first();



        return view('studentAdmin.home.homeContent', ['student' => $student]);
    }

    public function editProfile() {
        $id = Session::get('id');
        $depertment = Depertment::where('publicationStatus', 1)->get();
        $studentById = studentData::where('id', $id)->first();
        return view('studentAdmin.home.editStudent', ['studentById' => $studentById, 'depertment' => $depertment]);
    }

    public function updateStudent(Request $request) {
        $imageUrl = $this->imageExistStatus($request);
        $id = Session::get('id');
        $student = studentData::find($request->id);


        $student->fatherName = $request->fatherName;
        $student->motherName = $request->motherName;
        $student->DOBirth = $request->DOBirth;
        $student->address = $request->address;
        $student->phone = $request->phone;
        $student->relagion = $request->relagion;
        $student->blood = $request->blood;
        $student->country = $request->country;
        $student->studentImage = $imageUrl;

        $student->password = $request->password;
        $student->save();
        return redirect('/Dashbord')->with('massege', 'Student Info Update Successfully');
    }

    private function imageExistStatus($request) {
        $studentById = studentData::where('id', $request->id)->first();
        $studentImage = $request->file('studentImage');
        if ($studentImage) {

            $name = $studentImage->getClientOriginalName();
            $uploadPath = 'public/studentImage/';
            $studentImage->move($uploadPath, $name);
            $imageUrl = $uploadPath . $name;
        } else {

            $imageUrl = $studentById->studentImage;
        }
        return $imageUrl;
    }

    public function logout() {
        Session::put('id', '');
        Session::put('studentId', '');
        Session::put('studentName', '');
        Session::put('massege', 'You are Successfully Logout');
        return redirect('/forStudent');
    }

    public function logout_auth() {
        session_start();
        $id = Session::get('id');
        if ($id == NULL) {
            return redirect('/forStudent')->send();
        }
    }

    public function viewCourseDetails() {
        $depertment = Session::get('depertmentId');
        $course = DB::table('courses')
                // ->join('depertments','courses.depertmentName','=','depertments.id')
                ->join('teacher_datas', 'courses.courseInstructor', '=', 'teacher_datas.id')
                ->select('courses.*', 'teacher_datas.teacherName')
                ->where('depertmentId', $depertment)
                ->get();

        return view('studentAdmin.course.viewCourseDetails', ['course' => $course]);
    }

    public function paymentLogin() {
        $this->logout_auth();

        $samister = Samister::where('publicationStatus', 1)->get();


        return view('studentadmin.paymentLogin.paymentLogin', ['samister' => $samister]);
    }

    public function registerLogin(Request $request) {

        $studentId = Session::get('studentId');
        $paymentNo = $request->paymentRecipt;
        $samister = $request->samisterName;
        $depertment = Session::get('depertmentId');

        $registerUser = DB::table('payments')
                ->where('studentId', $studentId)
                ->where('paymentNo', $paymentNo)
                ->where('samisterName', $samister)
                ->first();

        if ($registerUser) {

            Session::put('paymentNo', $registerUser->paymentNo);


            $samisterId = $registerUser->samisterName;

            $studentInfo = DB::table('payments')
                    ->join('student_datas', 'payments.studentId', '=', 'student_datas.studentId')
                    ->select('payments.*', 'student_datas.studentName')
                    ->where('payments.studentId', $studentId)
                    ->first();

            $courseInfo = DB::table('courses')
                    ->select('courses.*')
                    ->where('depertmentName', $depertment)
                    ->get();

            $samisterInfo = DB::table('samisters')
                    ->select('samisters.*')
                    ->where('id', $samisterId)
                    ->get();

            $depertmentInfo = DB::table('depertments')
                    ->select('depertments.*')
                    ->where('id', $depertment)
                    ->get();






            return view('studentAdmin.course.courseRegister', ['studentInfo' => $studentInfo, 'courseInfo' => $courseInfo, 'samisterInfo' => $samisterInfo, 'depertmentInfo' => $depertmentInfo]);
        } else {
            Session::put('massege', 'Your Recipt No Invalid!!');
            return redirect('/course/registration');
        }
    }

    public function storeCourseInformation(Request $request) {

        $samisterName = $request->samisterName;
        $courseName = $request->courseName;
        $studentId = $request->studentId;

        $checkCourse = DB::table('register_Courses')
                ->where('studentId', $studentId)
                ->where('samisterName', $samisterName)
                ->where('courseName', $courseName)
                ->first();

        if ($checkCourse) {

            //Do somethis here later

            return 'You are already taken this Course';
        } else {
            $registerCourse = new registerCourse();
            $registerCourse->studentId = $request->studentId;
            $registerCourse->studentName = $request->studentName;
            $registerCourse->depermentName = $request->depermentName;
            $registerCourse->samisterName = $request->samisterName;
            $registerCourse->courseName = $request->courseName;
            $registerCourse->status = $request->status;
            $registerCourse->save();


            return redirect('/view/registerCourse')->with('massege', 'Successfully application for this Course. its now Under Review!!!');
        }
    }

    public function courseRegister() {
        return view('studentAdmin.course.courseRegister');
    }

    public function viewRegisterCourse() {
        $id = Session::get('studentId');

        $semister = Samister::all();

        $course = DB::table('register_courses')
                ->join('samisters', 'register_courses.samisterName', '=', 'samisters.id')
                ->join('courses', 'register_courses.courseName', '=', 'courses.id')
                ->select('register_courses.*', 'samisters.samisterName', 'courses.courseName')
                ->where('studentId', $id)
                ->get();

        /*
          echo '<pre>';
          print_r($course);
          echo '</pre>';
          exit();
         * 
         */


        return view('studentAdmin.course.viewRegisterCourse', ['course' => $course, 'semister' => $semister]);
    }

    public function registerCourseBySemister(Request $request) {

        $id = Session::get('studentId');

        $semister = $request->samisterName;
        
        $course = DB::table('register_courses')
                ->join('samisters', 'register_courses.samisterName', '=', 'samisters.id')
                ->join('courses', 'register_courses.courseName', '=', 'courses.id')
                ->select('register_courses.*', 'samisters.samisterName','samisters.id', 'courses.courseName')
                ->where('studentId', $id)
                ->where('samisters.id',$semister)
                ->get();
        
        return view('studentAdmin.course.viewRegisterCourseBySamister', ['course' => $course]);
      
    }

}
