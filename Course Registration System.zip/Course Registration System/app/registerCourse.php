<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class registerCourse extends Model
{
    //
}
