@extends('admin.master')

@section('content')
<div class="row">
    <div class="col-lg-2"></div>
    <div class="col-lg-8">
        <h3 class="text-center text-success">{{Session::get('massege')}}</h3>
        <hr/>
        <div class="well">
            <h3 class="text-center text-success">Student Payment List</h3>
            <table class="table table-hover table-bordered">
                <thead>
                    <tr>
                        
                        <th>Student Id</th>
                        <th>Payment Recipt No</th>
                        <th>Samister</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($payment as $payment)
                    <tr>
                        
                        <td>{{$payment->studentId}}</td>
                        <td>{{$payment->paymentNo}}</td>
                        <td>{{$payment->samisterName}}</td>
                        <td>
                            <a href="{{url('/payment/edit/'.$payment->id)}}" class="btn btn-success">
                                <span class="glyphicon glyphicon-edit"></span>
                            </a>
                            <a href="{{url('/payment/delete/'.$payment->id)}}" class="btn btn-danger" onclick="return confirm('Are you sure to delete This');">
                                <span class="glyphicon glyphicon-trash"></span>
                            </a>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection