@extends('admin.master')

@section('content')
<div class="row">
    <div class="col-lg-1"></div>
    <div class="col-lg-10">
        <h3 class="text-center text-success">Student List</h3>
        <hr/>
        <div class="well">
            
            <table class="table table-hover table-bordered">
                <thead>
                    <tr>
                        <th>Student Id</th>
                        <th>Student Name</th>
                        <th>Depertment</th>
                        <th>Phone No</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($student as $student)
                    <tr>
                        <td scope="row">{{$student->studentId}}</td>
                        <td>{{$student->studentName}}</td>
                        <td>{{$student->depertmentName}}</td>
                        <td>{{$student->phone}}</td>
                        <td>
                            <a href="{{url('/samister/view/'.$student->id)}}" class="btn btn-info">
                                <span class="glyphicon glyphicon-info-sign"></span>
                            </a>
                            <a href="{{url('/samister/edit/'.$student->id)}}" class="btn btn-success">
                                <span class="glyphicon glyphicon-edit"></span>
                            </a>
                            <a href="{{url('/samister/delete/'.$student->id)}}" class="btn btn-danger" onclick="return confirm('Are you sure to delete This');">
                                <span class="glyphicon glyphicon-trash"></span>
                            </a>
                            
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
