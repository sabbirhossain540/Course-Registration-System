@extends('admin.master')

@section('content')
<div class="row">
    <div class="col-lg-1"></div>
    <div class="col-lg-10">
        <h3 class="text-center text-success">Student Profile </h3>
        <hr/>
        <div class="well">
            <div class="col-lg-3">
                <hr>
                <table class="table table-bordered table-hover">
                    <tr>
                        <th>Student Image</th>
                    </tr>
                    <tr>
                        <td><img src="{{asset($student->studentImage)}}" alt="{{$student->studentName}}"  width="280px" height="300px"/></td>
                    </tr>
                </table>
            </div>
            <div class="col-lg-9">
                <hr>
                <table class="table table-bordered table-hover">
                    <tr>
                        <th>Student Id</th>
                        <th>{{ $student->studentId }}</th>
                    </tr>
                    <tr>
                        <th>Student Name</th>
                        <th>{{ $student->studentName }}</th>
                    </tr>
                    <tr>
                        <th>Depertment</th>
                        <th>{{ $student->depertmentName }}</th>
                    </tr>
                    <tr>
                        <th>Father Name</th>
                        <th>{{ $student->fatherName }}</th>
                    </tr>
                    <tr>
                        <th>Mother Name</th>
                        <th>{{$student->motherName}}</th>
                    </tr>
                    <tr>
                        <th>Dath of Birth</th>
                        <th>{{$student->DOBirth}}</th>
                    </tr>
                    <tr>
                        <th>Address</th>
                        <th>{{$student->address}}</th>
                    </tr>
                    <tr>
                        <th>Phone No</th>
                        <th>{{$student->phone}}</th>
                    </tr>
                    <tr>
                        <th>Relagion</th>
                        <th>{{$student->relagion}}</th>
                    </tr>
                    <tr>
                        <th>Blood</th>
                        <th>{{$student->blood}}</th>
                    </tr>
                    <tr>
                        <th>Country</th>
                        <th>{{$student->country}}</th>
                    </tr>
                </table>
            </div>
        </div>
    </div>
@endsection
