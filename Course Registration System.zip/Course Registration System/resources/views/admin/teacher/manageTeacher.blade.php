@extends('admin.master')

@section('content')
<div class="row">
    <div class="col-lg-1"></div>
    <div class="col-lg-10">
        <h3 class="text-center text-success">Teacher List</h3>
        <hr/>
        <div class="well">
            
            <table class="table table-hover table-bordered">
                <thead>
                    <tr>
                        <th>Teacher Id</th>
                        <th>Teacher Name</th>
                        <th>Dasingnation</th>
                        <th>Depertment</th>
                        <th>Phone No</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($teacher as $teacher)
                    <tr>
                        <td scope="row">{{$teacher->teacherId}}</td>
                        <td>{{$teacher->teacherName}}</td>
                        <td>{{$teacher->dasingnation}}</td>
                        <td>{{$teacher->depertmentName}}</td>
                        <td>{{$teacher->phone}}</td>
                        <td>
                            <a href="{{url('/teacher/view/'.$teacher->id)}}" class="btn btn-info">
                                <span class="glyphicon glyphicon-info-sign"></span>
                            </a>
                            <a href="{{url('/teacher/edit/'.$teacher->id)}}" class="btn btn-success">
                                <span class="glyphicon glyphicon-edit"></span>
                            </a>
                            <a href="{{url('/teacher/delete/'.$teacher->id)}}" class="btn btn-danger" onclick="return confirm('Are you sure to delete This');">
                                <span class="glyphicon glyphicon-trash"></span>
                            </a>
                            
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection

