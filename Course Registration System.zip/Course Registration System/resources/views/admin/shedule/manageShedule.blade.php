@extends('admin.master')
@section('content')
<div class="row">
    <div class="col-lg-1"></div>
    <div class="col-lg-10">
        <h3 class="text-center text-success">{{Session::get('massege')}}</h3>
        <hr/>
        <div class="well">
            <h3 class="text-center">Shedule Management</h3>
            <hr/>
            <table class="table table-hover table-bordered">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Section</th>
                        <th>Total Seat</th>
                        <th>Room No</th>
                        <th>Time Slot</th>
                        <th>Publication Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($shedule as $shedule)
                    <tr>
                        <td scope="row">{{$shedule->id}}</td>
                        <td>{{$shedule->sectionName}}</td>
                        <td>{{$shedule->seatNo}}</td>
                        <td>{{$shedule->roomNo}}</td>
                        <td>{{$shedule->timeSlot}}</td>
                        <td>{{$shedule->publicationStatus == 1 ? 'Published':'Unpublished'}}</td>
                        <td>
                            <a href="{{url('/shedule/edit/'.$shedule->id)}}" class="btn btn-success">
                                <span class="glyphicon glyphicon-edit"></span>
                            </a>
                            <a href="{{url('/shedule/delete/'.$shedule->id)}}" class="btn btn-danger" onclick="return confirm('Are you sure to delete This');">
                                <span class="glyphicon glyphicon-trash"></span>
                            </a>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection