@extends('admin.master')

@section('content')
<hr/>
<div class="row">
    <div class="col-lg-1"></div>
    <div class="col-lg-10">
        <h3 class="text-center text-success">{{Session::get('massege')}}</h3>
        <hr/>
        <div class="well">
            {!!Form::open(['url'=>'/shedule/save','method'=>'POST', 'class'=>'form-horizontal'])!!}
            <h3 class="text-center">Shedule Information</h3>
            <hr/>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Section</label>
                <div class="col-sm-10">
                    <input type="text" name="sectionName" class="form-control">
                    <span class="text-danger"> {{$errors->has('sectionName')?$errors->first('sectionName'):""}} </span>
                </div>

            </div>
            
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Total Seat</label>
                <div class="col-sm-10">
                    <input type="number" name="seatNo" class="form-control">
                    <span class="text-danger"> {{$errors->has('seatNo')?$errors->first('seatNo'):""}} </span>
                </div>

            </div>
            
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Class Room No</label>
                <div class="col-sm-10">
                    <input type="text" name="roomNo" class="form-control">
                    <span class="text-danger"> {{$errors->has('roomNo')?$errors->first('roomNo'):""}} </span>
                </div>

            </div>
            
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Time Slot</label>
                <div class="col-sm-10">
                    <input type="text" name="timeSlot" class="form-control">
                    <span class="text-danger"> {{$errors->has('timeSlot')?$errors->first('timeSlot'):""}} </span>
                </div>

            </div>

            
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Publication Status</label>
                <div class="col-sm-10">
                    <select class="form-control" name="publicationStatus">
                        <option>Select Publication Status</option>
                        <option value="1">Published</option>
                        <option value="0">Unpublished</option>
                    </select>
                </div>

            </div>

            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button name="btn" class="btn btn-success btn-block">Save Shedule Information</button>
                </div>

            </div>
            {!!Form::close()!!}
        </div>
    </div>
</div>
@endsection