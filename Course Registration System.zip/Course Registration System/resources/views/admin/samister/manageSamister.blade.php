@extends('admin.master')

@section('content')
<div class="row">
    <div class="col-lg-1"></div>
    <div class="col-lg-10">
        <h3 class="text-center text-success">{{Session::get('massege')}}</h3>
        <hr/>
        <div class="well">
            <table class="table table-hover table-bordered">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Samister Name</th>
                        <th>Samister Description</th>
                        <th>Publication Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($samister as $samister)
                    <tr>
                        <td scope="row">{{$samister->id}}</td>
                        <td>{{$samister->samisterName}}</td>
                        <td>{{$samister->samisterDescription}}</td>
                        <td>{{$samister->publicationStatus == 1 ? 'Published':'Unpublished'}}</td>
                        <td>
                            <a href="{{url('/samister/edit/'.$samister->id)}}" class="btn btn-success">
                                <span class="glyphicon glyphicon-edit"></span>
                            </a>
                            <a href="{{url('/samister/delete/'.$samister->id)}}" class="btn btn-danger" onclick="return confirm('Are you sure to delete This');">
                                <span class="glyphicon glyphicon-trash"></span>
                            </a>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
