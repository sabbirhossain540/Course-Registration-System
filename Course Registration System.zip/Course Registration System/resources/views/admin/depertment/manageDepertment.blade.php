@extends('admin.master')

@section('content')
<div class="row">
    <div class="col-lg-1"></div>
    <div class="col-lg-10">
        <h3 class="text-center text-success">{{Session::get('massege')}}</h3>
        <hr/>
        <div class="well">
            <table class="table table-hover table-bordered">
                <thead>
                    <tr>
                       
                        <th>Depertment Name</th>
                        <th>Depertment Description</th>
                        <th>Publication Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($depertment as $depertment)
                    <tr>
                        
                        <td>{{$depertment->depertmentName}}</td>
                        <td>{{$depertment->depertmentDescription}}</td>
                        <td>{{$depertment->publicationStatus == 1 ? 'Published':'Unpublished'}}</td>
                        <td>
                            <a href="{{url('/depertment/edit/'.$depertment->id)}}" class="btn btn-success">
                                <span class="glyphicon glyphicon-edit"></span>
                            </a>
                            <a href="{{url('/depertment/delete/'.$depertment->id)}}" class="btn btn-danger" onclick="return confirm('Are you sure to delete This');">
                                <span class="glyphicon glyphicon-trash"></span>
                            </a>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection

