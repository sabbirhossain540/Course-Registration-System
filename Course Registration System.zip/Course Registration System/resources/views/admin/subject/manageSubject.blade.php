@extends('admin.master')
@section('content')
<div class="row">
    <div class="col-lg-1"></div>
    <div class="col-lg-10">
        <h3 class="text-center text-success">{{Session::get('massege')}}</h3>
        <hr/>
        <div class="well">
            <table class="table table-hover table-bordered">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Subject Name</th>
                        <th>Subject Description</th>
                        <th>Publication Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($subject as $subject)
                    <tr>
                        <td scope="row">{{$subject->id}}</td>
                        <td>{{$subject->subjectName}}</td>
                        <td>{{$subject->subjectDescription}}</td>
                        <td>{{$subject->publicationStatus == 1 ? 'Published':'Unpublished'}}</td>
                        <td>
                            <a href="{{url('/subject/edit/'.$subject->id)}}" class="btn btn-success">
                                <span class="glyphicon glyphicon-edit"></span>
                            </a>
                            <a href="{{url('/subject/delete/'.$subject->id)}}" class="btn btn-danger" onclick="return confirm('Are you sure to delete This');">
                                <span class="glyphicon glyphicon-trash"></span>
                            </a>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
