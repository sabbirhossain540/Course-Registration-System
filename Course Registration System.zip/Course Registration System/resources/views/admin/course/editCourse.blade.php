@extends('admin.master')

@section('content')
<hr/>
<div class="row">
    <div class="col-lg-1"></div>
    <div class="col-lg-10">
        <h3 class="text-center text-success">{{Session::get('massege')}}</h3>
        <hr/>
        <div class="well">
            {!!Form::open(['url'=>'/course/update','method'=>'POST', 'class'=>'form-horizontal', 'name'=>'editCourseForm'])!!}
            <div class="form-group">
                <label for="inputEmail3" value="{{$courseById->courseCode}}" class="col-sm-2 control-label">Course Code</label>
                <div class="col-sm-10">
                    <input type="text" name="courseCode" value="{{$courseById->courseCode}}" class="form-control">
                    <input type="hidden" name="id" value="{{$courseById->id}}" class="form-control">
                    <span class="text-danger"> {{$errors->has('courseCode')?$errors->first('courseCode'):""}} </span>
                </div>

            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Course Name</label>
                <div class="col-sm-10">
                    <input type="text" name="courseName" value="{{$courseById->courseName}}" class="form-control">
                    <span class="text-danger"> {{$errors->has('courseName')?$errors->first('courseName'):""}} </span>
                </div>

            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Depertment Name</label>
                <div class="col-sm-10">
                    <select class="form-control" name="depertmentName" id="depertmentName" >
                        
                        
                        @foreach($depertment as $depertment)
                        <option value="{{$depertment->id}}">{{$depertment->depertmentName}}</option>
                        @endforeach
                    </select>
                </div>

            </div>
            
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Course Instructor</label>
                <div class="col-sm-10">
                    <select class="form-control" name="courseInstructor">
                       
                         @foreach($teacher as $teacher)
                        <option value="{{$teacher->id}}">{{$teacher->teacherName}}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Section</label>
                <div class="col-sm-10">
                    <input type="text" name="section" value="{{$courseById->section}}" class="form-control">
                    <span class="text-danger"> {{$errors->has('section')?$errors->first('section'):""}} </span>
                </div>

            </div>
            
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Total Seat</label>
                <div class="col-sm-10">
                    <input type="number" name="seatNo" value="{{$courseById->seatNo}}" class="form-control">
                    <span class="text-danger"> {{$errors->has('seatNo')?$errors->first('seatNo'):""}} </span>
                </div>

            </div>
            
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Publication Status</label>
                <div class="col-sm-10">
                    <select class="form-control" name="publicationStatus">
                        <option>Select Publication Status</option>
                        <option value="1">Published</option>
                        <option value="0">Unpublished</option>
                    </select>
                </div>

            </div>

            

            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button name="btn" class="btn btn-success btn-block">Update Course Information</button>
                </div>

            </div>
            {!!Form::close()!!}
        </div>
    </div>
</div>
<script>
    document.forms['editCourseForm'].elements['publicationStatus'].value={{$courseById->publicationStatus}}
</script>
@endsection