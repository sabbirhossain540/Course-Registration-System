@extends('admin.master')

@section('content')
<hr/>
<div class="row">
    <div class="col-lg-1"></div>
    <div class="col-lg-10">
        <h3 class="text-center text-success">{{Session::get('massege')}}</h3>
        <hr/>
        <div class="well">
            {!!Form::open(['url'=>'/course/save','method'=>'POST', 'class'=>'form-horizontal'])!!}
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Course Code</label>
                <div class="col-sm-10">
                    <input type="text" name="courseCode" class="form-control">
                    <span class="text-danger"> {{$errors->has('courseCode')?$errors->first('courseCode'):""}} </span>
                </div>

            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Course Name</label>
                <div class="col-sm-10">
                    <input type="text" name="courseName" class="form-control">
                    <span class="text-danger"> {{$errors->has('courseName')?$errors->first('courseName'):""}} </span>
                </div>

            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Depertment Name</label>
                <div class="col-sm-10">
                    <select class="form-control" name="depertmentName" id="depertmentName">
                        
                        
                        @foreach($depertment as $depertment)
                        <option value="{{$depertment->id}}">{{$depertment->depertmentName}}</option>
                        @endforeach
                    </select>
                </div>

            </div>
            
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Course Instructor</label>
                <div class="col-sm-10">
                    <select class="form-control" name="courseInstructor">
                         @foreach($teacher as $teacher)
                        <option value="{{$teacher->id}}">{{$teacher->teacherName}}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Section</label>
                <div class="col-sm-10">
                    <input type="text" name="section" class="form-control">
                    <span class="text-danger"> {{$errors->has('section')?$errors->first('section'):""}} </span>
                </div>

            </div>
            
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Total Seat</label>
                <div class="col-sm-10">
                    <input type="number" name="seatNo" class="form-control">
                    <span class="text-danger"> {{$errors->has('seatNo')?$errors->first('seatNo'):""}} </span>
                </div>

            </div>
            
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Publication Status</label>
                <div class="col-sm-10">
                    <select class="form-control" name="publicationStatus">
                        <option>Select Publication Status</option>
                        <option value="1">Published</option>
                        <option value="0">Unpublished</option>
                    </select>
                </div>

            </div>

            

            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button name="btn" class="btn btn-success btn-block">Save Course Information</button>
                </div>

            </div>
            {!!Form::close()!!}
        </div>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
       $(document).on('change','#depertmentName',function(){
         // console.log("hmm it work"); 
          
          var id = $(this).val();
          //console.log(teacher_id);
          
          $.ajax({
              type: 'get',
              url:'{!!URL::to('/findTeacherName')!!}',
              data:('id':id),
              success:function(data){
                  //console.log('success');
                  
                  console.log(data);
              },
              error:function(){
                  console.log("Not Working");
              }
          });
       }); 
    });
</script>
@endsection

