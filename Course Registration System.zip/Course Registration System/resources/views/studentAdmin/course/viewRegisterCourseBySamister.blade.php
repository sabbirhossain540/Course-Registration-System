@extends('studentAdmin.master')

@section('content')

<div class="row">
    <div class="col-lg-2"></div>
    <div class="col-lg-10">
        <h3 class="text-center text-denger">{{Session::get('massege')}}</h3>
        <hr/>

        <div class="well">

            <h3 class="text-center text-success">Samister Wise Course List</h3>
            <hr/>

            <table class="table table-hover table-bordered">
                <thead>
                    <tr>


                        <th>Course Name</th>
                        <th>Samister</th>
                        <th>Status</th>

                    </tr>
                </thead>
                <tbody>
                    @foreach($course as $course)
                    <tr>

                        <td>{{$course->samisterName}}</td>
                        <td>{{$course->courseName}}</td>
                        <td>{{$course->status}}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
    @endsection