@extends('studentAdmin.master')
@section('content')
<hr/>
<div class="row">
    <div class="col-lg-2"></div>
    <div class="col-lg-9">
        <h3 class="text-center text-success">Enter Student Information</h3>
        
        <hr/>
        <div class="well">
            {!!Form::open(['url'=>'/student/update','method'=>'POST', 'class'=>'form-horizontal','enctype'=>'multipart/form-data'])!!}
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Depertment</label>
                <div class="col-sm-10">
                    <select class="form-control"  name="depertmentId">
                        
                        @foreach($depertment as $depertment)
                        <option value="{{$depertment->id}}" readonly>{{$depertment->depertmentName}}</option>
                        @endforeach
                    </select>
                </div>  
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Student Id</label>
                <div class="col-sm-10">
                    <input type="text" name="studentId" value="{{$studentById->studentId}}" class="form-control" readonly="">
                    <input type="hidden" name="id" value="{{$studentById->id}}" class="form-control">
                    <span class="text-danger"> {{$errors->has('studentId')?$errors->first('studentId'):""}} </span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Student Name</label>
                <div class="col-sm-10">
                    <input type="text" name="studentName" value="{{$studentById->studentName}}" class="form-control" readonly="">
                    <span class="text-danger"> {{$errors->has('studentName')?$errors->first('studentName'):""}} </span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Father Name</label>
                <div class="col-sm-10">
                    <input type="text" name="fatherName" value="{{$studentById->fatherName}}" class="form-control">
                    <span class="text-danger"> {{$errors->has('fatherName')?$errors->first('fatherName'):""}} </span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Mother Name</label>
                <div class="col-sm-10">
                    <input type="text" name="motherName" value="{{$studentById->motherName}}" class="form-control">
                    <span class="text-danger"> {{$errors->has('motherName')?$errors->first('motherName'):""}} </span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Date of Birth</label>
                <div class="col-sm-10">
                    <input type="text" name="DOBirth" value="{{$studentById->DOBirth}}" class="form-control" placeholder="dd/mm/yy">
                    <span class="text-danger"> {{$errors->has('DOBirth')?$errors->first('DOBirth'):""}} </span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Address</label>
                <div class="col-sm-10">
                    <textarea class="form-control" name="address" rows="5">{{$studentById->address}}"</textarea>
                    <span class="text-danger">{{$errors->has('address')?$errors->first('address'):''}}</span>
                </div>

            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Phone No</label>
                <div class="col-sm-10">
                    <input type="text" name="phone" value="{{$studentById->phone}}" class="form-control" >
                    <span class="text-danger"> {{$errors->has('phone')?$errors->first('phone'):""}} </span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Relagion</label>
                <div class="col-sm-10">
                    <select class="form-control" name="relagion">
                        
                        <option value="{{$studentById->relagion}}">Islam</option>
                        <option value="hindu">Hindu</option>
                        <option value="other">Others</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Blood Group</label>
                <div class="col-sm-10">
                    <input type="text" name="blood" value="{{$studentById->blood}}" class="form-control" >
                    <span class="text-danger"> {{$errors->has('blood')?$errors->first('blood'):""}} </span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Nationality</label>
                <div class="col-sm-10">
                    <select class="form-control" name="country">
                        <option value="{{$studentById->country}}">{{$studentById->country}}</option>
                        <option value="Bangladesh">Bangladesh</option>
                        <option value="India">India</option>
                        <option value="Pakistan">Pakistan</option>
                    </select>
                </div>  
            </div>

            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Student Image</label>
                <div class="col-sm-10">
                    <input type="file" name="studentImage" accept="image/*" >
                    <img src="{{asset($studentById->studentImage)}}" height="150px" width="150px;">
                    <span class="text-danger"> {{$errors->has('studentImage')?$errors->first('studentImage'):""}} </span>
                </div>

            </div>

            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Username</label>
                <div class="col-sm-10">
                    <input type="email" name="email" value="{{$studentById->email}}" class="form-control" readonly="" >
                    <span class="text-danger"> {{$errors->has('email')?$errors->first('email'):""}} </span>
                </div>
            </div>
            
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Password</label>
                <div class="col-sm-10">
                    <input type="password" name="password" value="{{$studentById->password}}" class="form-control" >
                    <span class="text-danger"> {{$errors->has('password')?$errors->first('password'):""}} </span>
                </div>
            </div>
            


            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button name="btn" class="btn btn-success btn-block">Update Student Information</button>
                </div>

            </div>
            {!!Form::close()!!}
        </div>
    </div>
</div>
@endsection

