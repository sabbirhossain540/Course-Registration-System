<div class="navbar-default sidebar" role="navigation">
                        <div class="sidebar-nav navbar-collapse col-lg-3">
                            <ul class="nav" id="side-menu">

                                <li>
                                    <a href="{{url('/Dashbord')}}" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Dashboards</span> </a>
                                </li>

                                <li>
                                    <a href="{{url('/student/edit')}}" class=" hvr-bounce-to-right"><i class="fa fa-cog nav_icon"></i> <span class="nav-label">Edit Profile</span><span class="fa arrow"></span></a>
                                    
                                </li>
                                <li>
                                    <a href="{{url('/view/courseDetails')}}" class=" hvr-bounce-to-right"><i class="fa fa-list nav_icon"></i> <span class="nav-label">View Offer Course</span> </a>
                                </li>

                                <li>
                                    <a href="{{url('/course/registration')}}" class=" hvr-bounce-to-right"><i class="fa fa-th nav_icon"></i> <span class="nav-label">Register Course</span> </a>
                                </li>
                                <li>
                                    <a href="{{url('/view/registerCourse')}}" class=" hvr-bounce-to-right"><i class="fa fa-list nav_icon"></i> <span class="nav-label">View Register Course</span> </a>
                                </li>
                               
                            </ul>
                        </div>
                    </div>
            </nav>
