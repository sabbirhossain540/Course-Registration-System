<div class="stats" id="stats">
            <div class="container"> 
                <div class="inner_w3l_agile_grids">
                    <div class="col-md-3 w3layouts_stats_left w3_counter_grid">
                        <i class="fa fa-laptop" aria-hidden="true"></i>
                        <p class="counter">22</p>
                        <h3>Depertment</h3>
                    </div>
                    <div class="col-md-3 w3layouts_stats_left w3_counter_grid1">
                        <i class="fa fa-smile-o" aria-hidden="true"></i>
                        <p class="counter">165</p>
                        <h3>Courses</h3>
                    </div>
                    <div class="col-md-3 w3layouts_stats_left w3_counter_grid2">
                        <i class="fa fa-trophy" aria-hidden="true"></i>
                        <p class="counter">1563</p>
                        <h3>Student</h3>
                    </div>
                    <div class="col-md-3 w3layouts_stats_left w3_counter_grid3">
                        <i class="fa fa-user" aria-hidden="true"></i>
                        <p class="counter">245</p>
                        <h3>Teacher</h3>
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </div>	
        </div>

