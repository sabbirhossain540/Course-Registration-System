<div class="footer">
            <div class="f-bg-w3l">
                <div class="container">
                    <div class="col-md-4 w3layouts_footer_grid">
                        <h2>Follow <span>Us</span></h2>
                        <ul class="social_agileinfo">
                            <li><a href="#" class="w3_facebook"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#" class="w3_twitter"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#" class="w3_instagram"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="#" class="w3_google"><i class="fa fa-google-plus"></i></a></li>
                        </ul>
                    </div>
                    <div class="col-md-8 w3layouts_footer_grid">
                        <form action="#" method="post">
                            <input type="email" name="Email" placeholder="Email..." required="">
                            <input type="submit" value="">
                        </form>
                        <ul class="w3l_footer_nav">
                            <li><a href="{{url('/')}}" class="active">Home</a></li>
                            <li><a href="{{url('/Service')}}">Services</a></li>
                            <li><a href="{{url('/Gallery')}}">Gallery</a></li>
                            <li><a href="icons.html">Web Icons</a></li>
                            <li><a href="{{url('/Contact')}}">Mail Us</a></li>
                        </ul>
                        <p>© 2017 Daffodil Course Registration . All Rights Reserved |</p>
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </div>
        </div>