@extends('frontEnd.master')

@section('mainContent')
<div class="banner-silder">
            <div id="JiSlider" class="jislider">
                <ul>
                    <li>
                        <div class="w3layouts-banner-top">

                            <div class="container">
                                <div class="agileits-banner-info">
                                    <span>Education</span>
                                    <h3>For the Creatives</h3>
                                    <p>You can learn anything</p>

                                </div>	
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="w3layouts-banner-top w3layouts-banner-top1">
                            <div class="container">
                                <div class="agileits-banner-info">
                                    <span>Free</span>
                                    <h3>Premium Courses</h3>
                                    <p>You only have to know one thing</p>

                                </div>	
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="w3layouts-banner-top w3layouts-banner-top2">
                            <div class="container">
                                <div class="agileits-banner-info">
                                    <span>Education</span>
                                    <h3>For the Creatives</h3>
                                    <p>You can learn anything.</p>

                                </div>	

                            </div>
                        </div>
                    </li>

                </ul>
            </div>
        </div>

        <!-- //banner -->
        <!-- Modal1 -->
        <div class="modal fade" id="myModal2" tabindex="-1" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>

                        <div class="signin-form profile">
                            <h3 class="agileinfo_sign">Sign In</h3>	
                            <div class="login-form">
                                <form action="#" method="post">
                                    <input type="text" name="email" placeholder="E-mail" required="">
                                    <input type="password" name="password" placeholder="Password" required="">
                                    <div class="tp">
                                        <input type="submit" value="Sign In">
                                    </div>
                                </form>
                            </div>
                            <div class="login-social-grids">
                                <ul>
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-rss"></i></a></li>
                                </ul>
                            </div>
                            <p><a href="#" data-toggle="modal" data-target="#myModal3" > Don't have an account?</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- //Modal1 -->	
        <!-- Modal2 -->
        <div class="modal fade" id="myModal3" tabindex="-1" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>

                        <div class="signin-form profile">
                            <h3 class="agileinfo_sign">Sign Up</h3>	
                            <div class="login-form">
                                <form action="#" method="post">
                                    <input type="text" name="name" placeholder="Username" required="">
                                    <input type="email" name="email" placeholder="Email" required="">
                                    <input type="password" name="password" placeholder="Password" required="">
                                    <input type="password" name="password" placeholder="Confirm Password" required="">
                                    <input type="submit" value="Sign Up">
                                </form>
                            </div>
                            <p><a href="#"> By clicking register, I agree to your terms</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- //Modal2 -->	

        <!-- bootstrap-pop-up -->
        <div class="modal video-modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModal">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">

                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>						
                    </div>
                    <section>
                        <div class="modal-body">
                            <h5>Mastering</h5>
                            <img src="{{asset('public/frontEnd/')}}/images/2.jpg" alt=" " class="img-responsive" />
                            <p>Ut enim ad minima veniam, quis nostrum 
                                exercitationem ullam corporis suscipit laboriosam, 
                                nisi ut aliquid ex ea commodi consequatur? Quis autem 
                                vel eum iure reprehenderit qui in ea voluptate velit 
                                e.
                                <i>" Quis autem vel eum iure reprehenderit qui in ea voluptate velit 
                                    esse quam nihil molestiae consequatur.</i></p>
                        </div>
                    </section>
                </div>
            </div>
        </div>
        <!-- //bootstrap-pop-up -->
        <!-- banner-bottom -->
        <div class="banner-bottom">
            <div class="container">
                <h3>Join <span class="fixed_w3"> Daffodil University</span> today to start discovering thousand of content with minimum <span class="fixed_w3"> effort and cost! </span></h3>
                <div class="agileits_banner_bottom_grids">
                    <div class="col-md-3 agileits_banner_bottom_grid">
                        <div class="hovereffect w3ls_banner_bottom_grid">
                            <img src="{{asset('public/frontEnd/')}}/images/1.jpg" alt=" " class="img-responsive" />
                            <div class="overlay">
                                <h4>Daffodil</h4>
                                <p>Education</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 agileits_banner_bottom_grid">
                        <div class="hovereffect w3ls_banner_bottom_grid">
                            <img src="{{asset('public/frontEnd/')}}/images/2.jpg" alt=" " class="img-responsive" />
                            <div class="overlay">
                                <h4>Daffodil</h4>
                                <p>Library</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 agileits_banner_bottom_grid">
                        <div class="hovereffect w3ls_banner_bottom_grid">
                            <img src="{{asset('public/frontEnd/')}}/images/3.jpg" alt=" " class="img-responsive" />
                            <div class="overlay">
                                <h4>University</h4>
                                <p>Environment</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 agileits_banner_bottom_grid">
                        <div class="hovereffect w3ls_banner_bottom_grid">
                            <img src="{{asset('public/frontEnd/')}}/images/4.jpg" alt=" " class="img-responsive" />
                            <div class="overlay">
                                <h4>Daffodil</h4>
                                <p>Reasource</p>
                            </div>
                        </div>
                    </div>
                    <div class="clearfix"> </div>
                </div>
                <div class="team-w3ls-row">
                    <h3 class="w3l_header w3_agileits_header">Our <span>Insrtuctors</span></h3>
                    <div class="agileits_banner_bottom_grids">
                        <div class="col-md-3 col-sm-6 team-grids">
                            <img src="{{asset('public/frontEnd/')}}/images/t1.jpg" alt=""/>
                            <div class="img-caption w3-agileits">
                                <div class="img-agileinfo-text">
                                    <h4>Alan Ipsum</h4>
                                    <p>English Instructor</p> 
                                    <div class="w3social-icons"> 
                                        <ul>
                                            <li><a href="#"><i class="fa fa-google-plus"></i> </a></li>
                                            <li><a href="#"><i class="fa fa-facebook"></i> </a></li>
                                            <li><a href="#"><i class="fa fa-twitter"></i> </a></li> 
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6 team-grids">
                            <img src="{{asset('public/frontEnd/')}}/images/t2.jpg" alt=""/>
                            <div class="img-caption">
                                <div class="img-agileinfo-text">
                                    <h4>Lana del Rey</h4>
                                    <p>PHP Instructor </p>
                                    <div class="w3social-icons"> 
                                        <ul>
                                            <li><a href="#"><i class="fa fa-google-plus"></i> </a></li>
                                            <li><a href="#"><i class="fa fa-facebook"></i> </a></li>
                                            <li><a href="#"><i class="fa fa-twitter"></i> </a></li> 
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6 team-grids">
                            <img src="{{asset('public/frontEnd/')}}/images/t3.jpg" alt=""/>
                            <div class="img-caption">
                                <div class="img-agileinfo-text">
                                    <h4>Mark John</h4>
                                    <p>English Instructor</p> 
                                    <div class="w3social-icons"> 
                                        <ul>
                                            <li><a href="#"><i class="fa fa-google-plus"></i> </a></li>
                                            <li><a href="#"><i class="fa fa-facebook"></i> </a></li>
                                            <li><a href="#"><i class="fa fa-twitter"></i> </a></li> 
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6 team-grids">
                            <img src="{{asset('public/frontEnd/')}}/images/t4.jpg" alt=""/>
                            <div class="img-caption">
                                <div class="img-agileinfo-text">
                                    <h4>Peter Parker</h4>
                                    <p>PHP Instructor</p>
                                    <div class="w3social-icons"> 
                                        <ul>
                                            <li><a href="#"><i class="fa fa-google-plus"></i> </a></li>
                                            <li><a href="#"><i class="fa fa-facebook"></i> </a></li>
                                            <li><a href="#"><i class="fa fa-twitter"></i> </a></li> 
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"> </div> 
                    </div>
                </div>

            </div>
        </div>
        <!-- //banner-bottom -->

        <!-- services -->
        <div class="services" id="services">
            <div class="container">
                <h3 class="w3l_header w3_agileits_header two">Our <span>Benefits</span></h3>
                <div class="agile_inner_w3ls-grids two">
                    <div class="col-md-3 service-box">
                        <figure class="icon">
                            <span>1</span>
                            <i class="fa fa-graduation-cap" aria-hidden="true"></i>
                        </figure>
                        <h5>Experienced Faculty</h5>
                        <p>Lorem ipsum dolor sit amet.doloremque laudantium elerisque.</p>
                    </div>
                    <div class="col-md-3 service-box">

                        <figure class="icon">
                            <span>2</span>
                            <i class="fa fa-laptop" aria-hidden="true"></i>
                        </figure>
                        <h5>Online Courses</h5>
                        <p>Lorem ipsum dolor sit amet.doloremque laudantium elerisque.</p>
                    </div>
                    <div class="col-md-3 service-box">
                        <figure class="icon">
                            <span>3</span>
                            <i class="fa fa-book" aria-hidden="true"></i>
                        </figure>
                        <h5>Central Library</h5>
                        <p>Lorem ipsum dolor sit amet.doloremque laudantium elerisque.</p>
                    </div>
                    <div class="col-md-3 service-box">
                        <figure class="icon">
                            <span>4</span>
                            <i class="fa fa-lightbulb-o" aria-hidden="true"></i>
                        </figure>
                        <h5>Creative Thinking</h5>
                        <p>Lorem ipsum dolor sit amet.doloremque laudantium elerisque.</p>
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </div>
        </div>
        <!-- //services -->

        <!-- blog -->
        <div class="blog" id="blog">
            <div class="container">

                <h3 class="w3l_header w3_agileits_header"> Latest <span>  News</span></h3>
                <div class="agile_inner_w3ls-grids">

                    <div class="col-sm-6 w3-agile-post-grids">
                        <div class="w3-agile-post-img w3-agile-post-img1">
                            <a href="#" data-toggle="modal" data-target="#myModal"> 
                                <ul>
                                    <li><i class="fa fa-comments" aria-hidden="true"></i> 05</li>
                                    <li><i class="fa fa-heart" aria-hidden="true"></i> 874</li>
                                    <li><i class="fa fa-share" aria-hidden="true"></i> Share</li>
                                </ul>
                            </a>
                        </div>
                        <div class="w3-agile-post-info">
                            <h4><a href="#" data-toggle="modal" data-target="#myModal">Quisque a rhoncus</a></h4>
                            <ul>
                                <li>By <a href="#">Admin</a></li>
                                <li>Jan 28th,2017</li>
                            </ul>
                            <p>Suspendisse in nisl at ipsum molestie dignissim. Pellentesque est nisi, blandit eget aliquam sed, consequat nec risus.</p>
                        </div>
                    </div>
                    <div class="col-sm-6 w3-agile-post-grids">
                        <div class="w3-agile-post-img w3-agile-post-img2">
                            <a href="#" data-toggle="modal" data-target="#myModal"> 
                                <ul>
                                    <li><i class="fa fa-comments" aria-hidden="true"></i> 21</li>
                                    <li><i class="fa fa-heart" aria-hidden="true"></i> 287</li>
                                    <li><i class="fa fa-share" aria-hidden="true"></i> Share</li>
                                </ul>
                            </a>
                        </div>
                        <div class="w3-agile-post-info">
                            <h4><a href="#" data-toggle="modal" data-target="#myModal">Quisque a rhoncus</a></h4>
                            <ul>
                                <li>By <a href="#">Admin</a></li>
                                <li>Feb 24th,2017</li>
                            </ul>
                            <p>Suspendisse in nisl at ipsum molestie dignissim. Pellentesque est nisi, blandit eget aliquam sed, consequat nec risus.</p>
                        </div>
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </div>
        </div>
        <!-- //blog -->
        <!-- stats -->
        @include('frontEnd.include.state')
        <!-- //stats -->

        <!-- testimonials -->		
        <div class="testimonials">
            <div class="col-md-6 w3layouts_event_left">
                <img src="{{asset('public/frontEnd/')}}/images/test.jpg" alt=" " class="img-responsive" />
            </div>
            <div class="col-md-6 w3layouts_event_right">
                <h3>what people says</h3>
                <section class="slider">
                    <div class="flexslider">
                        <ul class="slides">
                            <li>
                                <div class="w3_event_right_grid">
                                    <div class="w3layouts_event_right_para">
                                        <p>Nam tempus lobortis sem non ornare. Curabitur dignissim interdum sem, et mollis lorem. 
                                            Mauris hendrerit, mi in aliquet egestas, nisi mi vestibulum turpis.</p>
                                        <div class="w3layouts_event_right_para_pos">
                                            <i class="fa fa-quote-left" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                    <div class="w3_agile_event_right_grids">
                                        <div class="col-xs-4 w3_agile_event_right_grid_left">
                                            <img src="{{asset('public/frontEnd/')}}/images/test1.jpg" alt=" " class="img-responsive" />
                                        </div>
                                        <div class="col-xs-8 w3_agile_event_right_grid_right">
                                            <h4>Williams Stall</h4>
                                            <p>Graphic & web designer</p>
                                        </div>
                                        <div class="clearfix"> </div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="w3_event_right_grid">
                                    <div class="w3layouts_event_right_para">
                                        <p>Nam tempus lobortis sem non ornare. Curabitur dignissim interdum sem, et mollis lorem. 
                                            Mauris hendrerit, mi in aliquet egestas, nisi mi vestibulum turpis.</p>
                                        <div class="w3layouts_event_right_para_pos">
                                            <i class="fa fa-quote-left" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                    <div class="w3_agile_event_right_grids">
                                        <div class="col-xs-4 w3_agile_event_right_grid_left">
                                            <img src="{{asset('public/frontEnd/')}}/images/test2.jpg" alt=" " class="img-responsive" />
                                        </div>
                                        <div class="col-xs-8 w3_agile_event_right_grid_right">
                                            <h4>Catherine Mark</h4>
                                            <p>PHP & web developer</p>
                                        </div>
                                        <div class="clearfix"> </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </section>
            </div>
            <div class="clearfix"> </div>
        </div>
        
        @endsection
