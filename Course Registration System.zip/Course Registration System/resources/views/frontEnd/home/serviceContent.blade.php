@extends('frontEnd.master')

@section('mainContent')
<div class="banner1">

    <div class="w3_agileits_service_banner_info">
        <h2>Services</h2>
    </div>
</div>
<!-- //banner -->
<!-- Modal1 -->
<div class="modal fade" id="myModal2" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>

                <div class="signin-form profile">
                    <h3 class="agileinfo_sign">Sign In</h3>	
                    <div class="login-form">
                        <form action="#" method="post">
                            <input type="text" name="email" placeholder="E-mail" required="">
                            <input type="password" name="password" placeholder="Password" required="">
                            <div class="tp">
                                <input type="submit" value="Sign In">
                            </div>
                        </form>
                    </div>
                    <div class="login-social-grids">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-rss"></i></a></li>
                        </ul>
                    </div>
                    <p><a href="#" data-toggle="modal" data-target="#myModal3" > Don't have an account?</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- //Modal1 -->	
<!-- Modal2 -->
<div class="modal fade" id="myModal3" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>

                <div class="signin-form profile">
                    <h3 class="agileinfo_sign">Sign Up</h3>	
                    <div class="login-form">
                        <form action="#" method="post">
                            <input type="text" name="name" placeholder="Username" required="">
                            <input type="email" name="email" placeholder="Email" required="">
                            <input type="password" name="password" placeholder="Password" required="">
                            <input type="password" name="password" placeholder="Confirm Password" required="">
                            <input type="submit" value="Sign Up">
                        </form>
                    </div>
                    <p><a href="#"> By clicking register, I agree to your terms</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- //Modal2 -->	

<!-- services -->
<div class="services two">
    <div class="container">
        <h3 class="w3l_header w3_agileits_header">Offered <span>Services</span></h3>
        <div class="wthree_services_grids">	
            <div class="col-md-6 wthree_services_grid_left">
                <h3>THE TOP POPULAR <span>COURSES</span> FOR YOU</h3>
                <h4>Choose your course</h4>
                <p> Sed quis eleifend leo. Phasellus iaculis, 
                    metus facilisis gravida dapibus, ligula dolor placerat dolor, eget 
                    cursus neque risus quis tortor varius augue ut mauris condimentum dictum.</p>
                <p> Sed quis eleifend leo. Phasellus iaculis, 
                    metus facilisis gravida dapibus, ligula dolor placerat dolor, eget 
                    cursus neque risus quis tortor varius augue ut mauris condimentum dictum.</p>

            </div>
            <div class="col-md-6 wthree_services_grid_right">
                <div class="col-md-4 agileits_w3layouts_service_grid">
                    <div class="agile_service_grd">
                        <i class="fa fa-share-alt" aria-hidden="true"></i>
                    </div>
                    <h4>Social Media</h4>
                    <p>Tortor varius augue ut mauris dictum.</p>
                </div>
                <div class="col-md-4 agileits_w3layouts_service_grid">
                    <div class="agile_service_grd">
                        <i class="fa fa-laptop" aria-hidden="true"></i>
                    </div>
                    <h4>Business</h4>
                    <p>Tortor varius augue ut mauris dictum.</p>
                </div>
                <div class="col-md-4 agileits_w3layouts_service_grid">
                    <div class="agile_service_grd">
                        <i class="fa fa-camera" aria-hidden="true"></i>
                    </div>
                    <h4>Photography</h4>
                    <p>Tortor varius augue ut mauris dictum.</p>
                </div>
                <div class="col-md-4 agileits_w3layouts_service_grid">
                    <div class="agile_service_grd">
                        <i class="fa fa-database" aria-hidden="true"></i>
                    </div>
                    <h4>Software</h4>
                    <p>Tortor varius augue ut mauris dictum.</p>
                </div>
                <div class="col-md-4 agileits_w3layouts_service_grid">
                    <div class="agile_service_grd">
                        <i class="fa fa-microphone" aria-hidden="true"></i>
                    </div>
                    <h4>Language</h4>
                    <p>Tortor varius augue ut mauris dictum.</p>
                </div>
                <div class="col-md-4 agileits_w3layouts_service_grid">
                    <div class="agile_service_grd">
                        <i class="fa fa-comments-o" aria-hidden="true"></i>
                    </div>
                    <h4>Communication</h4>
                    <p>Tortor varius augue ut mauris dictum.</p>
                </div>
                <div class="clearfix"> </div>
            </div>
            <div class="clearfix"> </div>
        </div>
    </div>
</div>
<!-- //services -->

<!-- stats -->
 @include('frontEnd.include.state')

<!-- //stats -->

<!-- stats-bottom -->
<div class="stats-bottom contact">
    <div class="container">
        <h3 class="w3l_header w3_agileits_header">Featured <span>Services</span></h3>
        <div class="agileinfo_services_grids">
            <div class="col-md-4 agileinfo_services_grid">
                <div class="agileinfo_services_grid1">
                    <h4>Best Lab</h4>
                    <p>Phasellus a porttitor metus, vitae ultrices nibh. Sed eu fermentum nunc.</p>
                    <div class="agileinfo_services_grid1_pos">
                        <span class="glyphicon glyphicon-user" aria-hidden="true"></span>
                    </div>
                </div>
            </div>
            <div class="col-md-4 agileinfo_services_grid">
                <div class="agileinfo_services_grid1">
                    <h4>Best Teachers</h4>
                    <p>Phasellus a porttitor metus, vitae ultrices nibh. Sed eu fermentum nunc.</p>
                    <div class="agileinfo_services_grid1_pos">
                        <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
                    </div>
                </div>
            </div>
            <div class="col-md-4 agileinfo_services_grid">
                <div class="agileinfo_services_grid1">
                    <h4>Low Cost Services</h4>
                    <p>Phasellus a porttitor metus, vitae ultrices nibh. Sed eu fermentum nunc.</p>
                    <div class="agileinfo_services_grid1_pos">
                        <span class="glyphicon glyphicon-retweet" aria-hidden="true"></span>
                    </div>
                </div>
            </div>
            <div class="clearfix"> </div>
        </div>
        <div class="w3agile_services_grids">
            <div class="col-md-4 agileinfo_services_grid">
                <div class="agileinfo_services_grid1">
                    <h4>Best Class rooms</h4>
                    <p>Phasellus a porttitor metus, vitae ultrices nibh. Sed eu fermentum nunc.</p>
                    <div class="agileinfo_services_grid1_pos">
                        <span class="glyphicon glyphicon-share" aria-hidden="true"></span>
                    </div>
                </div>
            </div>
            <div class="col-md-4 agileinfo_services_grid">
                <div class="agileinfo_services_grid1">
                    <h4>Online training</h4>
                    <p>Phasellus a porttitor metus, vitae ultrices nibh. Sed eu fermentum nunc.</p>
                    <div class="agileinfo_services_grid1_pos">
                        <span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>
                    </div>
                </div>
            </div>
            <div class="col-md-4 agileinfo_services_grid">
                <div class="agileinfo_services_grid1">
                    <h4>Drawing lessons</h4>
                    <p>Phasellus a porttitor metus, vitae ultrices nibh. Sed eu fermentum nunc.</p>
                    <div class="agileinfo_services_grid1_pos">
                        <span class="glyphicon glyphicon-usd" aria-hidden="true"></span>
                    </div>
                </div>
            </div>
            <div class="clearfix"> </div>
        </div>
    </div>
</div>
@endsection

