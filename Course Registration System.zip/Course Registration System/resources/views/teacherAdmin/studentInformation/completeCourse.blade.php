@extends('teacherAdmin.master')
@section('content')
<div class="row">
  
    <div class="col-lg-12">
        <h3 class="text-center text-success">Registered Course List</h3>
        <hr/>
       
        <div class="well">
            
            <table class="table table-hover table-bordered">
                <thead>
                    <tr>
                        <th>Samister</th>
                        <th>Course Name</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($courseInformation as $courseInformation)
                    <tr>
                        <td scope="row">{{$courseInformation->samisterName}}</td>
                        <td>{{$courseInformation->courseName}}</td>
                        <td>{{$courseInformation->status == 'Conform' ? 'Complete':''}}</td>
                        
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection