@extends('teacherAdmin.master')

@section('content')
<div class="row">
    
    <div class="col-lg-12">
        <h3 class="text-center text-success">{{Session::get('massege')}}</h3>
        <hr/>
        <div class="well">
            <h3 class="text-center">Teacher Profile</h3>
            <div class="col-lg-3">
                <hr>
                <table class="table table-bordered table-hover">
                    <tr>
                        <th>Teacher Image</th>
                    </tr>
                    <tr>
                        <td><img src="{{asset($teacher->teacherImage)}}" alt="{{$teacher->teacherName}}"  width="350px" height="350px"/></td>
                    </tr>
                </table>
            </div>
            <div class="col-lg-9">
                <hr>
                <table class="table table-bordered table-hover">
                    <tr>
                        <th>Teacher Id</th>
                        <th>{{ $teacher->teacherId }}</th>
                    </tr>
                    <tr>
                        <th>Teacher Name</th>
                        <th>{{ $teacher->teacherName }}</th>
                    </tr>
                    <tr>
                        <th>Desingnation</th>
                        <th>{{ $teacher->dasingnation }}</th>
                    </tr>
                    <tr>
                        <th>Depertment</th>
                        <th>{{ $teacher->depertmentName }}</th>
                    </tr>
                    <tr>
                        <th>Father Name</th>
                        <th>{{ $teacher->fatherName }}</th>
                    </tr>
                    <tr>
                        <th>Mother Name</th>
                        <th>{{$teacher->motherName}}</th>
                    </tr>
                    <tr>
                        <th>Dath of Birth</th>
                        <th>{{$teacher->DOBirth}}</th>
                    </tr>
                    <tr>
                        <th>Address</th>
                        <th>{{$teacher->address}}</th>
                    </tr>
                    <tr>
                        <th>Phone No</th>
                        <th>{{$teacher->phone}}</th>
                    </tr>
                    <tr>
                        <th>Relagion</th>
                        <th>{{$teacher->relagion}}</th>
                    </tr>
                    <tr>
                        <th>Blood</th>
                        <th>{{$teacher->blood}}</th>
                    </tr>
                    <tr>
                        <th>Country</th>
                        <th>{{$teacher->country}}</th>
                    </tr>
                </table>
            </div>
        </div>
    </div>
@endsection

