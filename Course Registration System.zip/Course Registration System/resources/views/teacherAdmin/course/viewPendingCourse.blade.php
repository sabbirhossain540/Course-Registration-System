@extends('teacherAdmin.master')

@section('content')

<div class="row">
    
    <div class="col-lg-12">
        <h3 class="text-center text-denger">{{Session::get('massege')}}</h3>
        <hr/>
        
        <div class="well">
            
            <h3 class="text-center text-success">Register Course List</h3>
            <hr/>
            <div class="col-lg-12" style="margin-bottom: 10px;">
                <form method="post" action="{{url('/view/registerCourse')}}">
                <div class="form-group">
                    <label for="inputEmail3" class="col-sm-2 control-label"><input type="text" name="studentId" class="form-control" placeholder="Student Id"></label>
                    <label for="inputEmail3" class="col-sm-2 control-label"><input type="text" name="samisterName" class="form-control"></label>
                    <div class="col-sm-1">
                        <button name="btn" class="btn btn-success btn-block">Search</button>
                    </div>

                </div>
                
            </form>
        </div>
            
            <table class="table table-hover table-bordered">
                <thead>
                    <tr>
                        <th>Student Id</th>
                        <th>Student Name</th>
                        <th>Samister</th>
                        <th>Course Name</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($pendingCourse as $pendingCourse)
                    <tr>
                        <td scope="row">{{$pendingCourse->studentId}}</td>
                        <td>{{$pendingCourse->studentName}}</td>
                        <td>{{$pendingCourse->samisterName}}</td>
                        <td>{{$pendingCourse->courseName}}</td>
                        <td>{{$pendingCourse->status}}</td>
                        <td>
                            <a href="{{url('/pendingCourse/edit/'.$pendingCourse->id)}}" class="btn btn-success">
                                <span class="glyphicon glyphicon-edit"></span>
                            </a>
                            <a href="{{url('/pandingCourse/delete/'.$pendingCourse->id)}}" class="btn btn-danger" onclick="return confirm('Are you sure to delete This');">
                                <span class="glyphicon glyphicon-trash"></span>
                            </a>
                        </td>
                        
                    </tr>
                    @endforeach
                        
                    
                    
                   
                </tbody>
            </table>
        </div>
    </div>
    @endsection
