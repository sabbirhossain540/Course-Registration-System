@extends('teacherAdmin.master')

@section('content')
<hr/>
<div class="row">
    <div class="col-lg-2"></div>
    <div class="col-lg-8">
        <h3 class="text-center text-success">{{Session::get('massege')}}</h3>
        <hr/>
        <h3 class="text-center text-success">Course Conformation Page</h3>
        <div class="well">

            {!!Form::open(['url'=>'/editPending/save','method'=>'POST', 'class'=>'form-horizontal'])!!}
            <div class="form-group">
                <div class="col-sm-2">
                <label for="inputEmail3" class="control-label">Student Id</label>
                </div>
                <div class="col-sm-10">
                    <input type="text" name="studentId" value="{{$editPendingCourse->studentId}}" class="form-control" readonly="">
                    <input type="hidden" name="id" value="{{$editPendingCourse->id}}" class="form-control" readonly="">
                    <span class="text-danger"> {{$errors->has('studentId')?$errors->first('studentId'):""}} </span>
                </div>

            </div>
            <div class="form-group">
                <div class="col-sm-2">
                <label for="inputEmail3" class="control-label">Student Name</label>
                </div>
                <div class="col-sm-10">
                    <input type="text" name="studentName" value="{{$editPendingCourse->studentName}}" class="form-control" readonly="">
                    <span class="text-danger"> {{$errors->has('studentName')?$errors->first('studentName'):""}} </span>
                </div>

            </div>
            <div class="form-group">
                <div class="col-sm-2">
                <label for="inputEmail3" class="control-label">Samister </label>
                </div>
                <div class="col-sm-10">
                    <input type="text" name="samisterName" value="{{$editPendingCourse->samisterName}}" class="form-control" readonly="">
                    <span class="text-danger"> {{$errors->has('samisterName')?$errors->first('samisterName'):""}} </span>
                </div>

            </div>
            <div class="form-group">
                <div class="col-sm-2">
                <label for="inputEmail3" class="control-label">Course Name</label>
                </div>
                <div class="col-sm-10">
                    <input type="text" name="courseName" value="{{$editPendingCourse->courseName}}" class="form-control" readonly="">
                    <span class="text-danger"> {{$errors->has('courseName')?$errors->first('courseName'):""}} </span>
                </div>

            </div>
           <div class="form-group">
                <div class="col-sm-2">
                <label for="inputEmail3" class="control-label">Status</label>
                </div>
                <div class="col-sm-10">
                    <select class="form-control"  name="status" >
                        <option value="{{$editPendingCourse->status}}">{{$editPendingCourse->status}}</option>
                        <option value="Pending">Pending</option>
                        <option value="Conform">Conform</option>
                        <option value="You are Not Eligible for this course">You are Not Eligible for this course</option>
                    </select>
                </div>

            </div>
            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button name="btn" class="btn btn-success btn-block">Conform Registration</button>
                </div>

            </div>
            
            {!!Form::close()!!}
        </div>
    </div>
</div>



@endsection