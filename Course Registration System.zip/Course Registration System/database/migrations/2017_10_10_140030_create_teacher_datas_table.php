<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTeacherDatasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('teacher_datas', function (Blueprint $table) {
            $table->increments('id');
            $table->string('depertmentId');
            $table->string('teacherId');
            $table->string('teacherName');
            $table->string('dasingnation');
            $table->string('fatherName');
            $table->string('motherName');
            $table->string('DOBirth');
            $table->text('address');
            $table->string('phone');
            $table->string('relagion');
            $table->string('blood');
            $table->string('country');
            $table->string('teacherImage');
            $table->string('email',100)->unique();
            $table->string('password');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('teacher_datas');
    }
}
