-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 07, 2018 at 02:30 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_courseregistration`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(10) UNSIGNED NOT NULL,
  `courseCode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `courseName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `depertmentName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `courseInstructor` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seatNo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `publicationStatus` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `courseCode`, `courseName`, `depertmentName`, `courseInstructor`, `section`, `seatNo`, `publicationStatus`, `created_at`, `updated_at`) VALUES
(7, 'SWE233', 'Object Oriented Programing', '4', '9', 'A', '32', '1', '2017-10-19 12:06:49', '2017-10-19 12:06:49'),
(8, 'SWE101', 'Introduction to Software Engineering', '4', '9', 'A', '36', '1', '2017-10-19 12:07:25', '2017-10-19 12:07:25'),
(9, 'SWE321', 'Database Management System', '4', '9', 'A', '35', '1', '2017-10-19 12:07:54', '2017-10-19 12:07:54'),
(10, 'SWE 421', 'Networking', '4', '11', 'A', '32', '1', '2017-10-20 11:43:17', '2017-10-20 11:43:17'),
(11, 'CSE201', 'Object Oriented Programing', '3', '10', 'A', '33', '1', '2017-10-20 11:43:58', '2017-10-20 11:44:16'),
(12, 'cse432', 'Algorthm', '3', '12', 'A', '21', '1', '2017-11-17 11:30:25', '2017-11-17 11:30:25');

-- --------------------------------------------------------

--
-- Table structure for table `depertments`
--

CREATE TABLE `depertments` (
  `id` int(10) UNSIGNED NOT NULL,
  `depertmentName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `depertmentDescription` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `publicationStatus` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `depertments`
--

INSERT INTO `depertments` (`id`, `depertmentName`, `depertmentDescription`, `publicationStatus`, `created_at`, `updated_at`) VALUES
(2, 'Textile Engineering', 'TXE', 1, '2017-10-04 05:37:30', '2017-10-04 05:37:30'),
(3, 'Computer Science And Engineering', 'CSE', 1, '2017-10-04 05:37:45', '2017-10-04 05:37:45'),
(4, 'Software Engineering', 'SWE SWE', 1, '2017-10-18 00:17:31', '2017-10-18 00:17:42');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(22, '2014_10_12_000000_create_users_table', 3),
(23, '2014_10_12_100000_create_password_resets_table', 3),
(24, '2017_09_19_221831_create_depertments_table', 3),
(25, '2017_09_21_110752_create_subjects_table', 3),
(26, '2017_09_21_121839_create_samisters_table', 3),
(27, '2017_09_21_133542_create_shedules_table', 3),
(31, '2017_10_03_192614_create_student_infos_table', 4),
(32, '2017_10_04_114426_create_tbl_student_table', 4),
(34, '2017_10_04_132141_create_student_datas_table', 5),
(35, '2017_10_10_140030_create_teacher_datas_table', 6),
(36, '2017_10_13_081534_create_courses_table', 7),
(38, '2017_10_14_125457_create_payments_table', 8),
(40, '2017_10_15_133259_create_register_courses_table', 9);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(10) UNSIGNED NOT NULL,
  `studentId` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `paymentNo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `samisterName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `studentId`, `paymentNo`, `samisterName`, `created_at`, `updated_at`) VALUES
(7, '540', '123456', '6', '2017-10-19 12:08:21', '2017-10-19 12:08:21'),
(8, '540', '123456', '5', '2017-10-20 11:44:30', '2017-10-20 11:44:30'),
(9, '140', '123458', '5', '2017-11-17 11:32:57', '2017-11-17 11:32:57');

-- --------------------------------------------------------

--
-- Table structure for table `register_courses`
--

CREATE TABLE `register_courses` (
  `id` int(10) UNSIGNED NOT NULL,
  `studentId` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `studentName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `depermentName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `samisterName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `courseName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `register_courses`
--

INSERT INTO `register_courses` (`id`, `studentId`, `studentName`, `depermentName`, `samisterName`, `courseName`, `status`, `created_at`, `updated_at`) VALUES
(14, '540', 'Md Sabbir Hossain', '4', '6', '7', 'Conform', '2017-10-19 12:10:32', '2017-10-19 12:12:22'),
(15, '540', 'Md Sabbir Hossain', '4', '6', '8', 'Pending', '2017-10-20 09:35:12', '2017-10-20 09:35:12'),
(16, '540', 'Md Sabbir Hossain', '4', '5', '10', 'Conform', '2017-10-20 11:45:13', '2017-10-20 11:46:23'),
(17, '140', 'malak', '3', '5', '12', 'Conform', '2017-11-17 11:37:52', '2017-11-17 11:42:15'),
(18, '540', 'Md Sabbir Hossain', '4', '5', '7', 'Conform', '2017-11-17 22:59:37', '2017-11-17 23:02:51'),
(19, '540', 'Md Sabbir Hossain', '4', '5', '8', 'Pending', '2017-11-18 03:23:14', '2017-11-18 03:23:14');

-- --------------------------------------------------------

--
-- Table structure for table `samisters`
--

CREATE TABLE `samisters` (
  `id` int(10) UNSIGNED NOT NULL,
  `samisterName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `samisterDescription` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `publicationStatus` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `samisters`
--

INSERT INTO `samisters` (`id`, `samisterName`, `samisterDescription`, `publicationStatus`, `created_at`, `updated_at`) VALUES
(4, 'Summer 2017', 'Summar Program', 1, '2017-10-19 11:57:46', '2017-10-19 11:57:46'),
(5, 'Spring 2017', 'Spring Samester', 1, '2017-10-19 11:58:03', '2017-10-19 11:58:03'),
(6, 'Fall 2017', 'Fall Semester', 1, '2017-10-19 11:58:19', '2017-10-19 11:58:19');

-- --------------------------------------------------------

--
-- Table structure for table `shedules`
--

CREATE TABLE `shedules` (
  `id` int(10) UNSIGNED NOT NULL,
  `sectionName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seatNo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roomNo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `timeSlot` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `publicationStatus` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shedules`
--

INSERT INTO `shedules` (`id`, `sectionName`, `seatNo`, `roomNo`, `timeSlot`, `publicationStatus`, `created_at`, `updated_at`) VALUES
(1, 'A', '36', '502', '12.00', 1, '2017-10-04 05:39:02', '2017-10-04 05:39:08');

-- --------------------------------------------------------

--
-- Table structure for table `student_datas`
--

CREATE TABLE `student_datas` (
  `id` int(10) UNSIGNED NOT NULL,
  `depertmentId` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `studentId` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `studentName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fatherName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `motherName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `DOBirth` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `relagion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `blood` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `studentImage` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `student_datas`
--

INSERT INTO `student_datas` (`id`, `depertmentId`, `studentId`, `studentName`, `fatherName`, `motherName`, `DOBirth`, `address`, `phone`, `relagion`, `blood`, `country`, `studentImage`, `email`, `password`, `created_at`, `updated_at`) VALUES
(11, '4', '540', 'Md Sabbir Hossain', 'Sadequl Islam', 'Marzina Begum', '02/08/1993', 'Dhaka', '01775526435', 'islam', 'AB+', 'Bangladesh', 'public/studentImage/WIN_20170821_18_03_20_Pro.jpg', 'sabbir308@gmail.com', '123456', '2017-10-19 11:59:47', '2017-10-19 11:59:47'),
(12, '3', '125', 'Esrafil Haque Srabon', 'Esarul Haque', 'Marzina Begum', '28/02/2006', 'Chapai Nawab Ganj', '01675246325', 'islam', 'AB+', 'Bangladesh', 'public/studentImage/WIN_20170819_19_51_15_Pro.jpg', 'srabon@gmail.com', '123456', '2017-10-19 12:01:05', '2017-10-19 12:01:05'),
(13, '3', '140', 'malak', 'yusuf', 'rabeya', '14/10/1899', 'sylhet', '0177542563', 'islam', 'AB+', 'Bangladesh', 'public/studentImage/s3.jpg', 'malik@gmail.com', '123456', '2017-11-17 11:32:30', '2017-11-17 11:32:30');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(10) UNSIGNED NOT NULL,
  `subjectName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subjectDescription` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `publicationStatus` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `subjectName`, `subjectDescription`, `publicationStatus`, `created_at`, `updated_at`) VALUES
(1, 'Database Management System', 'DBMS', 1, '2017-10-04 05:38:16', '2017-10-04 05:38:16');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student`
--

CREATE TABLE `tbl_student` (
  `id` int(10) UNSIGNED NOT NULL,
  `depertmentId` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `studentId` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `studentName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fatherName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `motherName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `DOBirth` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `relagion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `blood` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `teacher_datas`
--

CREATE TABLE `teacher_datas` (
  `id` int(10) UNSIGNED NOT NULL,
  `depertmentId` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `teacherId` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `teacherName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dasingnation` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fatherName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `motherName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `DOBirth` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `relagion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `blood` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `teacherImage` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teacher_datas`
--

INSERT INTO `teacher_datas` (`id`, `depertmentId`, `teacherId`, `teacherName`, `dasingnation`, `fatherName`, `motherName`, `DOBirth`, `address`, `phone`, `relagion`, `blood`, `country`, `teacherImage`, `email`, `password`, `created_at`, `updated_at`) VALUES
(9, '4', '12589', 'Rayhanul Rumel', 'Lecturer', 'xyz', 'abc', '24/10/1989', 'Dhaka', '01754263547', 'islam', 'A+', 'Bangladesh', 'public/teacherImage/45ac4968fd28312bb58738b4dc193a72.jpg', 'rumel@gmail.com', '123456', '2017-10-19 12:04:11', '2017-10-19 12:04:11'),
(10, '3', '12967', 'Alamgir Hossain', 'Senior Lecturer', 'xyz', 'abc', '19/11/1992', 'Sayedpur', '01125454544', 'islam', 'A+', 'Bangladesh', 'public/teacherImage/t1.jpg', 'alam@gmail.com', '123456', '2017-10-19 12:06:01', '2017-10-19 12:06:01'),
(12, '4', '124587', 'koushik', 'Senior Lecturer', 'xyz', 'abc', '12/12/1986', 'dhaka', '01125454544', 'islam', 'AB+', 'Select Country', 'public/teacherImage/t1.jpg', 'koushik@gmail.com', '123456', '2017-11-17 11:28:52', '2017-11-17 11:28:52');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `address`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Sabbir Hossain', 'Dhanmondi', 'sabbir308@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'R2bYsoSyHu54w9n611ApGa5FFwFBem4ldN8lq0K13wpIGEtZgXI1gWRLWUBU', '2017-10-04 00:04:40', '2017-10-04 00:04:40'),
(2, 'admin', 'admin', 'admin@gmail.com', '$2y$10$CjFrKZWqOizMx8BgjxH0S.4DU1rCgNhcJ2WEMVW9I6cFYcLyaqJTa', 'pQbKHArmehbsm7o5tjI8sW6hijZbXfm2AF1jbdd3cD302bxEhpOqejw5t70a', '2017-11-17 11:25:18', '2017-11-17 11:25:18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `depertments`
--
ALTER TABLE `depertments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register_courses`
--
ALTER TABLE `register_courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `samisters`
--
ALTER TABLE `samisters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shedules`
--
ALTER TABLE `shedules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_datas`
--
ALTER TABLE `student_datas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_datas_email_unique` (`email`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_student`
--
ALTER TABLE `tbl_student`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tbl_student_email_unique` (`email`);

--
-- Indexes for table `teacher_datas`
--
ALTER TABLE `teacher_datas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `teacher_datas_email_unique` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `depertments`
--
ALTER TABLE `depertments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `register_courses`
--
ALTER TABLE `register_courses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `samisters`
--
ALTER TABLE `samisters`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `shedules`
--
ALTER TABLE `shedules`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `student_datas`
--
ALTER TABLE `student_datas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_student`
--
ALTER TABLE `tbl_student`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `teacher_datas`
--
ALTER TABLE `teacher_datas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
